THE HUMPHREYS SUPPORT CONJECTURE
Complete article and computational supplement

Qiyue Tang
Zhili College, Tsinghua University, Beijing 100084, China
tangqy24@mails.tsinghua.edu.cn
November 12, 2026

1. Article and scope

Humphreys_support_conjecture.pdf is the 88-page article, including the
complete finite witness tables and 32 bibliography entries.
Humphreys_support_conjecture.tex is the complete single-file LaTeX source.
It has no external input files, figures, or bibliography database.
source/ contains the equivalent modular source, its section files, and the
exceptional-table generator and manifest.

The theorem concerns full cohomological support as a closed subset of the
nilpotent cone. For every connected reductive group over an algebraically
closed field of characteristic p > h, and every dominant highest weight,
it identifies the support of the corresponding indecomposable tilting
module with the orbit closure associated with its ordinary affine cell.
Here h is the largest Coxeter number of the irreducible root-system
components, with h = 1 for a torus.

This is the traditional p > h Humphreys support conjecture and the version
stated in Conjecture 3.3 and Remark 3.4 of the 2026 ICM survey cited in the
article. The article does not assert the stronger scheme-theoretic
annihilation statement in Conjecture 3.6 of that survey.

The proof in this edition incorporates explicit repairs to the original
classical half-switch argument, the E8 geometric intersection-form and
Fourier conventions, the source1221 propagation chain, and the derived
specialization argument. Review_statement_ZH.txt explains these points
and distinguishes completed checks from computations not independently
rerun. The manuscript cites the structural theorems it uses and gives the
new arguments, geometric calculations, and finite witnesses explicitly.

2. Compiling the article

With a standard current TeX distribution providing amsart, lmodern,
geometry, mathtools, mathrsfs, microtype, booktabs, longtable, enumitem,
and hyperref, run:

    latexmk -pdf Humphreys_support_conjecture.tex

Alternatively, run pdflatex repeatedly until references and longtable
widths stabilize. The modular source can be compiled in source/ with the
same command. No Python or Julia installation is needed to compile either
version. The distributed PDF was compiled from the standalone source.

3. Computational files

computations/ contains the full computational supplement. Start with
computations/README.txt for the exact arithmetic algorithms, preserved
input tables, provenance, hash manifest, dependencies, and execution limits.
The supplement includes the supplied Julia/CHEVIE programs and environment,
portable Python verifiers, recorded arithmetic results, and a portable
article-table generator.

From computations/, typical commands are:

    python3 -m pip install -r requirements.txt
    python3 run_checks.py --list
    python3 run_checks.py --quick
    python3 run_checks.py --full

The full Python suite is not a complete Julia/CHEVIE rerun. The bulk
noncentral restriction and cut arrays were checked through the programs
and consistency of the selected rows; they were not all independently
recomputed. The critical source DAGs, representations, final two
restrictions, and E8 localization and lattice calculations have separate
checks, described precisely in the supplement. Recorded success fields
are not accepted by the runner in place of executing its checks.

To reproduce the seven exceptional TeX tables into a new directory:

    python3 computations/table_generation/generate_exceptional_tables.py /path/to/new/tables

The archival generator in source/certificates/ preserves its original
workspace paths; use the portable entry point above for a new environment.
The original Julia layout can be prepared with:

    python3 computations/prepare_julia.py /path/to/new/julia-work

The preparation program explains the available entry points. Its standard
upgraded-coverage entry points do not by themselves regenerate every later
refinement. See computations/README.txt before interpreting the results.

4. Integrity and layout

The file computations/manifest.sha256 is relative to computations/ and
covers the distributed computational files other than itself. From that
directory, a standard checksum check is:

    sha256sum -c manifest.sha256

The ZIP archive preserves these paths. It contains no auxiliary TeX build files,
rendered page images, internal review transcripts, or copies of published
source papers. Computation logs retained in computations/ are part of the
preserved mathematical records and input provenance.
