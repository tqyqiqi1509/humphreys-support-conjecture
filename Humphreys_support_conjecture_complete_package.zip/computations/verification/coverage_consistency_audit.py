import os
from pathlib import Path
import csv,json,re,collections
P=Path(os.environ['HUMPHREYS_DATA_DIR'])
O=Path(os.environ['HUMPHREYS_RESULT_DIR'])

def read(name):return list(csv.DictReader((P/name).open(),delimiter='\t'))
report={};used=[]
for n in [7,8]:
 order={(int(r['lower']),int(r['upper'])) for r in read(f'E{n}_orbit_order.tsv')}
 chars=read(f'E{n}_characters.tsv');orb={r['orbit']:int(r['orbit_index']) for r in chars}
 bychar={r['character']:r for r in chars}
 sourcefile=f'E{n}_allaffine_upgraded_sources.tsv' if n==7 else 'E8_final_all_actual_sources.tsv'
 sources=read(sourcefile);sk={(int(s['affine_subset_mask']),int(s['H_character_index'])):s for s in sources}
 assert len(sk)==len(sources)
 for s in sources:
  assert orb[s['orbit']]==int(s['orbit_index'])
  for i in map(int,s['hit_W_characters'].split(',')):
   assert (int(chars[i-1]['orbit_index']),int(s['orbit_index'])) in order
 files=[f'E7_semisimple_{v}_upgraded_coverage.tsv' for v in range(1,9)] if n==7 else [v['table'] for v in json.loads((P/'E8_nine_vertex_geometric_complete_status.json').read_text())['vertices']]
 stats=[];counter=collections.Counter();direct=0;source_records={};central_recomputed=0;detailed=0
 for v,f in enumerate(files,1):
  rows=read(f);assert [int(r['index']) for r in rows]==list(range(1,len(rows)+1))
  wanted=[r for r in rows if r['trivial_local_system']=='true'];assert all(r['covered']=='true' for r in wanted)
  for r in rows:
   if r['covered']!='true':continue
   w=r['witness'];counter[w]+=1;key=None
   if w.startswith('fullW_'):key=(255,int(bychar[w.removeprefix('fullW_')]['index']))
   elif w=='affine_D8_mask510_char28':key=(510,28)
   elif w=='finite_E8_phi175_36_from_A7_source2794_geometric':bound=orb['D_4(a_1){+}A_1'];assert (v,int(r['index'])) in {(4,9),(9,62)}
   else:
    m=re.fullmatch(r'mask(\d+)_char(\d+)',w) or re.fullmatch(r'affine_(\d+)_char_(\d+)',w);assert m,w;key=tuple(map(int,m.groups()))
   if key:
    assert key in sk,(n,v,r,key)
    s=sk[key];bound=int(s['orbit_index']);source_records[key]=s
   assert (orb[r['ambient_orbit']],bound) in order,(n,v,w,r['ambient_orbit'],bound)
   if n==7 and v==1 or n==8 and v==1:
    i=int(r['index']);assert key and i in list(map(int,sk[key]['hit_W_characters'].split(',')))
    allowed=set(orb.values())
    for c in read(f'E{n}_upgraded_richardson_cuts.tsv'):
     if i in list(map(int,c['retained_W_characters'].split(','))):allowed&={a for a,b in order if b==int(c['orbit_index'])}
    inter=allowed&{a for a,b in order if b==bound}
    assert all((a,orb[r['ambient_orbit']]) in order for a in inter)
    central_recomputed+=1
   if n==8 and w.startswith(('fullW_','affine_D8_')):
    ff=f'E8_semisimple_{v}_incremental_witnesses.tsv' if v==2 else f'E8_semisimple_{v}_incremental_direct_witnesses.tsv'
    wr=[z for z in read(ff) if z['source']==w and z['local_index']==r['index']]
    assert len(wr)==1 and wr[0]['cut_succeeds']=='true' and wr[0]['local_character']==r['character'] and wr[0]['ambient_target']==r['ambient_orbit'];direct+=1
   if n==8 and v in [8,9] and key:
    wr=[z for kind in ['maximal','adaptive'] for z in read(f'E8_semisimple_{v}_final_{kind}_witnesses.tsv') if (int(z['affine_mask']),int(z['H_index']))==key and z['local_index']==r['index']]
    assert len(wr)>=1 and any(z['cut_succeeds']=='true' and int(z['multiplicity'])>0 and z['local_character']==r['character'] and z['ambient_target']==r['ambient_orbit'] and z['source_bound']==sk[key]['orbit'] for z in wr)
    detailed+=1
  stats.append({'vertex':v,'rows':len(rows),'required':len(wanted),'covered_required':sum(r['covered']=='true' for r in wanted),'covered_all':sum(r['covered']=='true' for r in rows),'table':f})
 report[str(n)]={'vertices':stats,'total_required':sum(s['required'] for s in stats),'total_covered_required':sum(s['covered_required'] for s in stats),'source_rows_checked':len(sources),'all_covered_source_keys_and_support_containment':True,'unique_used_source_blocks':len(source_records),'central_support_intersection_recomputed_from_existing_cut_and_induction_tables':central_recomputed,'incremental_direct_witness_rows_matched':direct,'vertices8_9_positive_detailed_witness_rows_matched':detailed}
 for key,s in sorted(source_records.items()):used.append({'rank':n,'mask':key[0],'H_index':key[1],**s})
# E8 concatenation must agree in all mathematical fields with final vertex tables.
allrows=read('E8_nine_vertex_geometric_complete_coverage.tsv');assert len(allrows)==686
for st in report['8']['vertices']:
 rows=read(st['table']);got=[r for r in allrows if int(r['vertex'])==st['vertex']]
 assert len(got)==len(rows)
 for r,g in zip(rows,got):
  for k in ['index','character','local_orbit','ambient_orbit','b','trivial_local_system','covered','witness']:assert r[k]==g[k]
changes=[]
for v,old,new in [(4,'E8_semisimple_4_incremental_direct_coverage.tsv','E8_semisimple_4_geometric_complete_coverage.tsv'),(9,'E8_semisimple_9_final_adaptive_coverage.tsv','E8_semisimple_9_geometric_complete_coverage.tsv')]:
 a=read(old);b=read(new);assert len(a)==len(b)
 for x,y in zip(a,b):
  if x['covered']!=y['covered']:changes.append({'vertex':v,'index':int(y['index']),'old':x['covered'],'new':y['covered'],'witness':y['witness']})
assert {(x['vertex'],x['index']) for x in changes}=={(4,9),(9,62)}
report['geometric_supersession_changes_exactly_two_rows']=changes
report['limitation']='No independent recomputation of all noncentral Chevie restriction multiplicities or all local Richardson cut tables was performed. This audit checks source-table provenance, every covered row source key/support inclusion, relevant detailed witness rows, central set intersections, exact final concatenation and final two replacements. Last two multiplicities are independently computed in independent_last_two_restrictions.json.'
(O/'coverage_consistency_audit.json').write_text(json.dumps(report,indent=2)+'\n');(O/'used_source_blocks.json').write_text(json.dumps(used,indent=2)+'\n')
print(json.dumps(report,indent=2))
