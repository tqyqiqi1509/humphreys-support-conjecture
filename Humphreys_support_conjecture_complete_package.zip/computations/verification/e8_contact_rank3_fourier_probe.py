import os
from fractions import Fraction as F
from itertools import combinations,permutations
from math import prod
from pathlib import Path
import sympy as s,json
perms=list(permutations(range(3)))
def det3(m):
 return sum((-1)**sum(p[i]>p[j]for i in range(3)for j in range(i+1,3))*prod(m[i][p[i]]for i in range(3))for p in perms)
def schur(lam,x):
 exp=[lam[i]+2-i for i in range(3)]
 return F(det3([[x[i]**exp[j]for j in range(3)]for i in range(3)]),det3([[x[i]**(2-j)for j in range(3)]for i in range(3)]))
parts=[(a,b,c)for a in range(4)for b in range(a+1)for c in range(b+1)]
parts.sort(key=lambda x:(sum(x),x))
gparts=[x for x in parts if x not in [(3,3,3),(3,2,2),(2,2,2)]]
def e2(x):return sum(a*b for a,b in combinations(x,2))
def e3(x):return prod(x)
def local(a,b):
 w=list(a)+list(b);triples=list(combinations(range(6),3));A=(0,1,2)
 dat=[]
 for I in triples:
  J=set(range(6))-set(I);x=[w[i]for i in I]
  den=prod(w[j]-w[i]for i in I for j in J)
  lam=sum(x);g=[schur(q,x)for q in gparts]
  f=[e2(x)-e2(a),e3(x)-e3(a)]
  dat.append((I,den,lam,g,f))
 M=s.Matrix(17,17,lambda i,j:sum(F(lam,den)*g[i]*g[j]for I,den,lam,g,f in dat))
 B=s.Matrix(2,17,lambda i,j:sum(F(1,den)*f[i]*g[j]for I,den,lam,g,f in dat))
 T=s.Matrix(2,2,lambda i,j:sum(F(1,lam*den)*f[i]*f[j]for I,den,lam,g,f in dat if I!=A))
 eN=prod(sum(w[i]for i in I)for I in triples if len(set(I)&set(A))<=1)
 out=eN*(T-B*M.inv()*B.T)
 return out,int(M.det())
def calc(a,bs):
 sums={k:F(0)for k in ['alpha','beta_h','gamma_h2','gamma_c2']};dets=set();locals=[]
 for I in combinations(range(5),3):
  J=set(range(5))-set(I);b=[bs[i]for i in I]
  den=prod(bs[j]-bs[i]for i in I for j in J)
  C,det=local(a,b);dets.add(det);h=sum(b)
  for k,z in [('alpha',C[1,1]),('beta_h',C[0,1]*h),('gamma_h2',C[0,0]*h*h),('gamma_c2',C[0,0]*e2(b))]:sums[k]+=F(z)/den
  locals.append({'b':b,'matrix':[[str(C[i,j])for j in range(2)]for i in range(2)]})
 return {'A':a,'B5':bs,'point_gram_determinants':sorted(dets),'integrals':{k:str(v)for k,v in sums.items()},'local_matrices':locals}
res={'status':'exact Fourier-projector calculation; geometric lattice audit recorded in draft','gpartitions':gparts,'runs':[]}
for a,bs in [([-7,2,5],[11,17,23,31,41]),([-13,3,10],[19,29,37,43,59])]:
 r=calc(a,bs);res['runs'].append(r);print({k:v for k,v in r.items()if k!='local_matrices'},flush=True)
(Path(os.environ['HUMPHREYS_RESULT_DIR'])/'e8_contact_rank3_fourier_probe.json').write_text(json.dumps(res,indent=2)+'\n')
