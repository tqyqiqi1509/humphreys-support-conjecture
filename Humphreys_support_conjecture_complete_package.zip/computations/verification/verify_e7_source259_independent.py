import os
"""Independent integer-root/spherical-Hecke verification; no Chevie/PyCox import."""
from pathlib import Path
from functools import lru_cache
from collections import defaultdict
import json,time
import numpy as np
start=time.time();base=Path(os.environ['HUMPHREYS_DATA_DIR'])
d=json.loads((base/'E7_phi15_source259_dag.json').read_text())
n=7;I=np.eye(n,dtype=np.int16);C=2*I.copy()
for a,b in [(1,3),(3,4),(2,4),(4,5),(5,6),(6,7)]:C[a-1,b-1]=C[b-1,a-1]=-1
R=[]
for s in range(n):
 A=I.copy();A[s,:]-=C[s,:];R.append(A)
def key(A):return tuple(map(int,A.reshape(-1)))
idkey=key(I)
@lru_cache(None)
def mat(w):
 A=I.copy()
 for s in w:A=A@R[s-1]
 return key(A)
@lru_cache(None)
def action(s,k):
 A=R[s-1]@np.array(k,dtype=np.int16).reshape(n,n)
 while True:
  j=next((j for j in d['parabolic_J'] if np.all(A[:,j-1]<=0)),None)
  if j is None:break
  A=A@R[j-1]
 return key(A)
words={idkey:()};lens={idkey:0};byindex={}
for v in d['canonical_vectors']:
 for t in v['terms']:
  w=tuple(t['coset_word']);k=mat(w);words[k]=w;lens[k]=len(w);byindex[t['index']]=k
# Coset actions may introduce extra shorter terms during bar expansion.
def root_length(k):
 # For reduced right coset representatives, recover length from positive roots.
 A=np.array(k,dtype=np.int16).reshape(n,n)
 return sum(np.all(A@a<=0) for a in positive)
roots=set(key(R[0]) for _ in [])
rr={tuple(map(int,I[:,i])) for i in range(n)};todo=list(rr)
while todo:
 a=todo.pop()
 for s in range(n):
  b=tuple(map(int,R[s]@np.array(a,dtype=np.int16)))
  if b not in rr:rr.add(b);todo.append(b)
positive=[np.array(a,dtype=np.int16) for a in rr if all(z>=0 for z in a)]
assert len(positive)==63
@lru_cache(None)
def length(k):return lens.get(k,root_length(k))
def add(dst,k,e,c):
 if c:dst[k,e]+=c

def multiply(s,v,bar=False):
 a=defaultdict(int)
 for (k,e),c in v.items():
  j=action(s,k)
  if j==k:
   if bar:add(a,k,e+1,c)
   else:add(a,k,e+1,c);add(a,k,e-1,c)
  elif length(j)>length(k):
   add(a,j,e,c)
   if bar:add(a,k,e+1,c);add(a,k,e-1,-c)
   else:add(a,k,e+1,c)
  else:
   add(a,j,e,c)
   if not bar:add(a,k,e-1,c)
 return {k:c for k,c in a.items() if c}
@lru_cache(None)
def bar_basis(w):
 a={(idkey,0):1}
 for s in reversed(w):a=multiply(s,a,bar=True)
 return a
vectors={}
for v in d['canonical_vectors']:
 a={}
 for t in v['terms']:
  k=mat(tuple(t['coset_word']))
  for e,c in t['polynomial']:a[k,int(e)]=int(c)
 target=byindex[v['index']]
 assert a[target,0]==1
 assert all(e>0 and length(k)<length(target) for (k,e) in a if k!=target)
 b=defaultdict(int)
 for (k,e),c in a.items():
  for (j,f),a0 in bar_basis(words[k]).items():add(b,j,f-e,c*a0)
 assert {k:c for k,c in b.items() if c}==a,('bar',v['index'])
 vectors[v['index']]=a
checks=[];known=set()
for node in d['nodes']:
 i=node['index'];w=np.array(mat(tuple(node['full_word'])),dtype=np.int16).reshape(n,n)
 if node['method']=='partial_Levi_rank_le6':
  assert set(node['coset_word'])<=set(node['parabolic_nodes'])
  assert len(node['parabolic_nodes'])<=6
 else:
  assert node['predecessor'] in known
  a=defaultdict(int,multiply(node['simple'],vectors[node['predecessor']]))
  for k,c in vectors[i].items():a[k]-=c
  for term in node['corrections']:
   for k,c in vectors[term['lower']].items():a[k]-=term['multiplicity']*c
   y=np.array(mat(tuple(term['lower_full_word'])),dtype=np.int16).reshape(n,n)
   rel=np.array(mat(tuple(term['relative_word'])),dtype=np.int16).reshape(n,n)
   assert rel@y==w if False else True
   assert np.array_equal(rel@y,w)
   assert set(term['relative_word'])<=set(term['parabolic_nodes'])
   assert len(term['parabolic_nodes'])<=6
  assert not any(a.values()),('product',i)
 known.add(i);checks.append(i)
receipt={'status':'PASS','independent_engine':'Python integer root matrices and Laurent polynomial dictionaries','positive_roots':len(positive),'bar_invariant_canonical_vectors':len(vectors),'dag_nodes_verified':checks,'multiplication_identities':len(checks)-1,'all_coset_witnesses_verified':True,'seconds':round(time.time()-start,3)}
(base/'E7_source259_independent_verification.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
