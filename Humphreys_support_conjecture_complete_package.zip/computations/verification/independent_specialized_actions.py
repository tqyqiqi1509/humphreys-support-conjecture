import os
from pathlib import Path
from functools import lru_cache
from collections import defaultdict
import json,time
import numpy as np
from scipy.sparse import csr_matrix
ROOT=Path(os.environ['HUMPHREYS_DATA_DIR'])
OUT=Path(os.environ['HUMPHREYS_RESULT_DIR'])
class Spherical:
 def __init__(self,n,J):
  self.n=n;self.J=J;self.I=np.eye(n,dtype=np.int16);self.C=2*self.I.copy()
  for a,b in [(1,3),(3,4),(2,4),(4,5),(5,6),(6,7),(7,8)]:
   if b<=n:self.C[a-1,b-1]=self.C[b-1,a-1]=-1
  self.R=[]
  for s in range(n):
   A=self.I.copy();A[s,:]-=self.C[s,:];self.R.append(A)
  rr={tuple(map(int,self.I[:,i])) for i in range(n)};todo=list(rr)
  while todo:
   a=todo.pop()
   for R in self.R:
    b=tuple(map(int,R@a))
    if b not in rr:rr.add(b);todo.append(b)
  self.positive=np.array([a for a in rr if all(z>=0 for z in a)],dtype=np.int16).T
  assert self.positive.shape[1]==(63 if n==7 else 120)
  self.identity=self.I.tobytes()
 def matrix(self,k):return np.frombuffer(k,dtype=np.int16).reshape(self.n,self.n)
 def key(self,word):
  A=self.I.copy()
  for s in word:A=A@self.R[s-1]
  return A.tobytes()
 @lru_cache(None)
 def length(self,k):return int(np.all(self.matrix(k)@self.positive<=0,axis=0).sum())
 @lru_cache(None)
 def action(self,s,k):
  A=self.R[s-1]@self.matrix(k)
  while True:
   j=next((j for j in self.J if np.all(A[:,j-1]<=0)),None)
   if j is None:return A.tobytes()
   A=A@self.R[j-1]
 def mul(self,s,V):
  Z=defaultdict(int)
  for (k,e),c in V.items():
   j=self.action(s,k)
   if j==k:Z[k,e+1]+=c;Z[k,e-1]+=c
   else:
    Z[j,e]+=c;Z[k,e+(1 if self.length(j)>self.length(k) else -1)]+=c
  return {k:c for k,c in Z.items() if c}
 @lru_cache(None)
 def canon(self,k):
  if k==self.identity:return {(k,0):1}
  l=self.length(k)
  s=next(s for s in range(1,self.n+1) if self.length(self.action(s,k))==l-1)
  Z=defaultdict(int,self.mul(s,self.canon(self.action(s,k))))
  assert Z[k,0]==1 and all(e>=0 for (_,e),c in Z.items() if c)
  lowers=sorted({j for (j,e),c in Z.items() if j!=k and c},key=self.length,reverse=True)
  for j in lowers:
   c=Z.get((j,0),0)
   if c:
    for t,a in self.canon(j).items():Z[t]-=c*a
  Z={t:c for t,c in Z.items() if c}
  assert all(c>0 and (e>0 or j==k) for (j,e),c in Z.items())
  return Z
 def compare(self,word,terms):
  k=self.key(word);assert self.length(k)==len(word)
  V=self.canon(k);expected=defaultdict(int)
  for (j,e),c in V.items():expected[j]+=c
  actual={self.key(t['word']):int(t['coefficient']) for t in terms}
  assert actual==expected,('mismatch',len(actual),len(expected))
  return V

def sparse_generators(d):
 R=[];n=d['dimension']
 for entries in d['sparse_generators']:
  a=np.asarray(entries,dtype=np.int64);R.append(csr_matrix((a[:,2],(a[:,0]-1,a[:,1]-1)),shape=(n,n)))
 return R

started=time.time();report={}
# E7: exact matrix, parabolic sum reconstructed from A6 transversals.
d=json.loads((ROOT/'E7_phi15_source259_receipt.json').read_text());R=[np.asarray(a,dtype=object) for a in d['generators']];I=np.eye(15,dtype=object)
edges={(1,3),(3,4),(2,4),(4,5),(5,6),(6,7)}
for i,x in enumerate(R):
 assert np.array_equal(x@x,I)
 for j in range(i):
  A=x@R[j];z=I.copy()
  for _ in range(3 if (j+1,i+1) in edges else 2):z=z@A
  assert np.array_equal(z,I)
J=[1,3,4,5,6,7];e=I.copy()
for k in range(len(J)):
 f=I.copy();v=I.copy()
 for j in range(k,-1,-1):v=v@R[J[j]-1];f+=v
 e=e@f
assert np.array_equal(e,np.asarray(d['parabolic_sum'],dtype=object))
S=Spherical(7,J);V=S.compare(d['coset_word'],d['terms'])
Z=np.zeros((15,15),dtype=object)
for t in d['terms']:
 a=I.copy()
 for s in t['word']:a=a@R[s-1]
 Z+=int(t['coefficient'])*(a@e)
assert np.array_equal(Z,np.asarray(d['matrix'],dtype=object));assert int(np.trace(Z))==20160
assert sum(int(x)**2 for x in Z.flat)==2649894912
report['E7_source259']={'all_coxeter_relations':True,'parabolic_sum_reconstructed':True,'canonical_coefficients_reconstructed':True,'terms':len(d['terms']),'trace':int(np.trace(Z)),'sum_squares':sum(int(x)**2 for x in Z.flat)}
# E7 source43 rational smoothness checked by full-flag maximal-coset coefficients.
w43=[5,4,2,3,1,4,3,5,4,2];V43=S.canon(S.key(w43))
assert all(c==1 and e==len(w43)-S.length(k) for (k,e),c in V43.items())
report['E7_source43']={'coset_length':10,'all_partial_IC_polynomials_one':True,'standard_terms':len(V43)}
print('E7 exact actions and source43 reconstructed',time.time()-started,flush=True)
# E8 source2794: independently reconstruct its ordinary spherical KL vector.
d=json.loads((ROOT/'E8_A7_phi175_source2794_modular_receipt.json').read_text());cert=json.loads((ROOT/'E8_A7_source2794_geometric_certificate.json').read_text());word=list(map(int,cert['source']['coset_word'].split(',')))
S8=Spherical(8,d['parabolic_nodes']);V8=S8.compare(word,d['terms'])
print('E8 source2794 ordinary KL vector reconstructed',time.time()-started,flush=True)
# Exact action with int64 norm bounds at each operation; no modular inference.
R=sparse_generators(d);n=d['dimension'];norm=max(int(np.max(abs(x).sum(axis=1))) for x in R);bound=0

def apply(word,v):
 global bound
 for s in reversed(word):
  b=int(np.max(abs(v)))*norm;assert b<2**62;bound=max(bound,b);v=R[s-1]@v
 return v
exact=json.loads((ROOT/'E8_A7_phi175_source2794_exact_action_pending_source.json').read_text())
v=np.asarray(exact['seed_vector'],dtype=np.int64)
assert np.array_equal(v%d['auxiliary_prime'],np.asarray(d['seed_vector'])%d['auxiliary_prime'])
for factor in d['parabolic_coset_factors']:
 z=np.zeros(n,dtype=np.int64)
 for w in factor:
  a=apply(w,v);b=int(np.max(abs(z)))+int(np.max(abs(a)));assert b<2**62;bound=max(bound,b);z+=a
 v=z
assert all(np.array_equal(R[s-1]@v,v) for s in d['parabolic_nodes'])
q=d['auxiliary_prime'];assert np.array_equal(v%q,np.asarray(d['invariant_vector'])%q)
out=np.zeros(n,dtype=np.int64)
for t in d['terms']:
 a=apply(t['word'],v);c=int(t['coefficient']);b=int(np.max(abs(out)))+abs(c)*int(np.max(abs(a)));assert b<2**62;bound=max(bound,b);out+=c*a
exact=json.loads((ROOT/'E8_A7_phi175_source2794_exact_action_pending_source.json').read_text())
assert np.array_equal(v,np.asarray(exact['invariant_vector']));assert np.array_equal(out,np.asarray(exact['result_vector']))
assert out[0]==-241920;assert sum(int(x)**2 for x in out)==17245228105728
report['E8_source2794']={'ordinary_canonical_coefficients_reconstructed':True,'standard_terms':len(d['terms']),'integral_nonzero_action':True,'nonzero_coordinate':1,'nonzero_value':int(out[0]),'sum_squares':sum(int(x)**2 for x in out),'max_integer_operation_bound':bound,'source_p_independence':'separate geometric proof, not inferred from this arithmetic'}
report['seconds']=time.time()-started
(OUT/'independent_specialized_actions.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
