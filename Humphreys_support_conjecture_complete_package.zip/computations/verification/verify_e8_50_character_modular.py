import os
"""Identify the integral 50-dimensional representation exactly.

Coxeter relations are checked over Z. Class traces are checked modulo q>2d.
Finite-group character traces are integers of absolute value<=d, hence these
modular trace checks determine them exactly and identify the ordinary irrep.
"""
import hashlib,json,time,tomllib
from pathlib import Path
import numpy as np
from scipy.sparse import csr_matrix,eye
base=Path(os.environ['HUMPHREYS_DATA_DIR'])
repfile=base/'E8_phi50_positive_rep.toml';clsfile=base/'E8_phi50_class_checks.toml'
r=tomllib.loads(repfile.read_text());c=tomllib.loads(clsfile.read_text())
n=r['dimension'];q=1000003;assert q>2*n
R=[]
for ts in r['sparse_generators']:
 a=np.asarray(ts,dtype=np.int64);R.append(csr_matrix((a[:,2],(a[:,0]-1,a[:,1]-1)),shape=(n,n)))
I=eye(n,format='csr',dtype=np.int64)
norm=max(int(np.max(abs(x).sum(axis=1))) for x in R)
assert norm**6<2**62
edges={(1,3),(3,4),(2,4),(4,5),(5,6),(6,7),(7,8)}
for i,x in enumerate(R):
 assert (x@x-I).nnz==0
 for j in range(i):
  m=3 if (j+1,i+1) in edges else 2
  a=x@R[j];z=I
  for _ in range(m):z=z@a
  z=z-I;z.eliminate_zeros();assert z.nnz==0
print('INTEGRAL_COXETER_RELATIONS_PASS norm',norm,flush=True)
chunk=1
while chunk<8 and q*norm**(chunk+1)<2**62:chunk+=1
print('SAFE_INTEGER_CHUNK',chunk,flush=True)
results=[];started=time.time()
for k,cc in enumerate(c['classes']):
 z=np.eye(n,dtype=np.int64)
 for a,s in enumerate(reversed(cc['word'])):
  z=R[s-1]@z
  if (a+1)%chunk==0:z%=q
 z%=q;t=int(np.trace(z)%q);expected=int(cc['trace'])%q
 assert t==expected,(k,t,expected)
 results.append(dict(index=k+1,word_length=len(cc['word']),trace=cc['trace'],residue=t))
 if k%10==0:print('TRACE',k+1,'/',len(c['classes']),'seconds',round(time.time()-started,1),flush=True)
receipt=dict(dimension=n,label=c['label'],auxiliary_prime=q,integral_coxeter_relations=True,
 exact_trace_identification_reason='Finite-order integral representation has integer trace in [-dimension,dimension]; prime exceeds twice dimension.',
 max_generator_row_norm=norm,safe_chunk=chunk,all_class_traces=True,classes=results,
 representation_sha256=hashlib.sha256(repfile.read_bytes()).hexdigest(),class_input_sha256=hashlib.sha256(clsfile.read_bytes()).hexdigest())
(base/'E8_phi50_independent_character_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('ALL_112_CLASS_TRACES_IDENTIFIED_EXACTLY',flush=True)
