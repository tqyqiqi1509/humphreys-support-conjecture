import os
from fractions import Fraction
from itertools import combinations
from math import prod
import json
from pathlib import Path

def calc(weights):
    n=8
    out={s:Fraction(0) for s in ['hW2','c2W','c2U','hU2','hUhW']}
    for W in combinations(range(n),6):
        W=set(W); C=set(range(n))-W
        dw=prod(weights[j]-weights[i] for i in W for j in C)
        triples=list(combinations(sorted(W),3))
        for U in triples:
            U=set(U); Q=W-U
            du=prod(weights[j]-weights[i] for i in U for j in Q)
            numer=prod(sum(weights[i] for i in T) for T in triples if set(T)!=U)
            hW=sum(weights[i] for i in W);hU=sum(weights[i] for i in U)
            c2W=sum(weights[i]*weights[j] for i,j in combinations(W,2));c2U=sum(weights[i]*weights[j] for i,j in combinations(U,2))
            val=Fraction(numer,dw*du)
            for key,x in [('hW2',hW*hW),('c2W',c2W),('c2U',c2U),('hU2',hU*hU),('hUhW',hU*hW)]:out[key]+=val*x
    return {k:str(v) for k,v in out.items()}
res={'status':'conditional Fourier pairing identification; exact equivariant flag integrals only','weights':[]}
for w in ([1,2,3,4,5,6,7,8],[-11,-7,-4,-2,1,5,8,10]):
    res['weights'].append({'weights':w,'integrals':calc(w)})
print(json.dumps(res,indent=2))
(Path(os.environ['HUMPHREYS_RESULT_DIR'])/'e8_contact_fourier_vertex_probe.json').write_text(json.dumps(res,indent=2)+'\n')
