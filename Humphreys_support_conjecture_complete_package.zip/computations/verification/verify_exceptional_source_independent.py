import os
"""Independent integer-root/spherical-Hecke verification; no Chevie/PyCox import."""
from pathlib import Path
from functools import lru_cache
from collections import defaultdict
import json,time,sys
import numpy as np
start=time.time();base=Path(os.environ['HUMPHREYS_DATA_DIR'])
input_path=Path(sys.argv[1]);d=json.loads(input_path.read_text())
n=d['rank'];I=np.eye(n,dtype=np.int16);C=2*I.copy()
for a,b in [(1,3),(3,4),(2,4)]+[(j,j+1) for j in range(4,n)]:C[a-1,b-1]=C[b-1,a-1]=-1
R=[]
for s in range(n):
 A=I.copy();A[s,:]-=C[s,:];R.append(A)
def key(A):return tuple(map(int,A.reshape(-1)))
idkey=key(I)
@lru_cache(None)
def mat(w):
 A=I.copy()
 for s in w:A=A@R[s-1]
 return key(A)
@lru_cache(None)
def action(s,k):
 A=R[s-1]@np.array(k,dtype=np.int16).reshape(n,n)
 while True:
  j=next((j for j in d['parabolic_J'] if np.all(A[:,j-1]<=0)),None)
  if j is None:break
  A=A@R[j-1]
 return key(A)
words={idkey:()};lens={idkey:0};byindex={}
for v in d['canonical_vectors']:
 for t in v['terms']:
  w=tuple(t['coset_word']);k=mat(w);words[k]=w;lens[k]=len(w);byindex[t['index']]=k
# Coset actions may introduce extra shorter terms during bar expansion.
def root_length(k):
 # For reduced right coset representatives, recover length from positive roots.
 A=np.array(k,dtype=np.int16).reshape(n,n)
 return sum(np.all(A@a<=0) for a in positive)
roots=set(key(R[0]) for _ in [])
rr={tuple(map(int,I[:,i])) for i in range(n)};todo=list(rr)
while todo:
 a=todo.pop()
 for s in range(n):
  b=tuple(map(int,R[s]@np.array(a,dtype=np.int16)))
  if b not in rr:rr.add(b);todo.append(b)
positive=[np.array(a,dtype=np.int16) for a in rr if all(z>=0 for z in a)]
assert len(positive)==({7:63,8:120}[n])
for k,w in words.items():assert root_length(k)==len(w)
@lru_cache(None)
def length(k):return lens.get(k,root_length(k))
def add(dst,k,e,c):
 if c:dst[k,e]+=c

def multiply(s,v,bar=False):
 a=defaultdict(int)
 for (k,e),c in v.items():
  j=action(s,k)
  if j==k:
   if bar:add(a,k,e+1,c)
   else:add(a,k,e+1,c);add(a,k,e-1,c)
  elif length(j)>length(k):
   add(a,j,e,c)
   if bar:add(a,k,e+1,c);add(a,k,e-1,-c)
   else:add(a,k,e+1,c)
  else:
   add(a,j,e,c)
   if not bar:add(a,k,e-1,c)
 return {k:c for k,c in a.items() if c}
@lru_cache(None)
def bar_basis(w):
 a={(idkey,0):1}
 for s in reversed(w):a=multiply(s,a,bar=True)
 return a
vectors={}
for v in d['canonical_vectors']:
 a={}
 for t in v['terms']:
  k=mat(tuple(t['coset_word']))
  for e,c in t['polynomial']:a[k,int(e)]=int(c)
 target=byindex[v['index']]
 assert {e:c for (k,e),c in a.items() if k==target}=={0:1}
 assert all(c>0 for c in a.values())
 assert all(e>0 and length(k)<length(target) for (k,e) in a if k!=target)
 b=defaultdict(int)
 for (k,e),c in a.items():
  for (j,f),a0 in bar_basis(words[k]).items():add(b,j,f-e,c*a0)
 assert {k:c for k,c in b.items() if c}==a,('bar',v['index'])
 vectors[v['index']]=a
def matrix(w):return np.array(mat(tuple(w)),dtype=np.int16).reshape(n,n)
@lru_cache(None)
def longest(nodes):
 A=I.copy();w=[]
 while True:
  s=next((s for s in nodes if np.all(A[:,s-1]>=0)),None)
  if s is None:break
  A=A@R[s-1];w.append(s)
 assert root_length(key(A))==len(w)
 return tuple(w)
def finite_small(nodes):
 remaining=set(nodes)
 while remaining:
  todo=[remaining.pop()];component=[]
  while todo:
   s=todo.pop();component.append(s)
   adj={t for t in remaining if C[s-1,t-1]!=0}
   remaining-=adj;todo.extend(adj)
  assert len(component)<=6
def check_source(source,upper):
 file=input_path.with_name(f"E7_{source['source_tag']}_source{source['source_index']}_complete_dag.json")
 sub=json.loads(file.read_text());receipt=json.loads(file.with_name(file.stem+'_independent_verification.json').read_text())
 assert receipt['status']=='PASS'
 target=next(x for x in sub['nodes'] if x['index']==sub['target'])
 word=target['full_word'][::-1] if source.get('inverted',False) else target['full_word']
 assert np.array_equal(matrix(word),upper)
 assert np.array_equal(matrix(source['source_full_word']),upper)
def check_partial(node,w):
 nodes=set(node['parabolic_nodes']);J=set(d['parabolic_J']);K=nodes&J
 assert set(node['intersection_J'])==K
 assert set(node['coset_word'])<=nodes
 x=matrix(node['coset_word'])
 assert all(np.all(x[:,j-1]>=0) for j in J)
 assert np.array_equal(x@matrix(longest(tuple(sorted(J)))),w)
 if node['method']=='partial_Levi_known_upper':
  upper=matrix(node['upper_word'])
  assert np.array_equal(x@matrix(longest(tuple(sorted(K)))),upper)
  assert all(np.all(upper[:,j-1]<=0) for j in K)
  check_source(node['upper_source'],upper)
 else:finite_small(nodes)
def check_large_correction(term,w,y):
 nodes=set(term['parabolic_nodes']);u=matrix(term['common_minimal_right_coset_word'])
 upper=matrix(term['upper_word']);lower=matrix(term['lower_parabolic_word'])
 assert set(term['upper_word'])<=nodes and set(term['lower_parabolic_word'])<=nodes
 assert all(np.all(u[:,j-1]>=0) for j in nodes)
 if term.get('jensen_applied_after_inversion',False):
  ww=matrix(list(reversed(node['full_word'])));yy=matrix(list(reversed(term['lower_full_word'])))
 else:ww=w;yy=y
 assert np.array_equal(u@upper,ww) and np.array_equal(u@lower,yy)
 if 'upper_source' in term:check_source(term['upper_source'],upper)
 else:
  J=set(term['upper_source_J']);K=set(term['upper_source_Levi_K']);levi=set(term['upper_source_Levi_I'])
  x=matrix(term['upper_source_coset_word'])
  assert set(term['upper_source_coset_word'])<=levi and K==J&levi
  finite_small(levi)
  assert all(np.all(x[:,j-1]>=0) for j in J)
  expected=x@matrix(longest(tuple(sorted(J))))
  if term.get('upper_source_inverted',False):expected=np.rint(np.linalg.inv(expected)).astype(np.int16)
  assert np.array_equal(expected,upper)
checks=[];known=set()
for node in d['nodes']:
 i=node['index'];w=np.array(mat(tuple(node['full_word'])),dtype=np.int16).reshape(n,n)
 assert root_length(key(w))==len(node['full_word'])
 assert np.array_equal(matrix(node['coset_word'])@matrix(longest(tuple(d['parabolic_J']))),w)
 if node['method'].startswith('partial_Levi'):
  check_partial(node,w)
 else:
  assert node['predecessor'] in known
  a=defaultdict(int,multiply(node['simple'],vectors[node['predecessor']]))
  for k,c in vectors[i].items():a[k]-=c
  for term in node['corrections']:
   for k,c in vectors[term['lower']].items():a[k]-=term['multiplicity']*c
   y=np.array(mat(tuple(term['lower_full_word'])),dtype=np.int16).reshape(n,n)
   rel=np.array(mat(tuple(term['relative_word'])),dtype=np.int16).reshape(n,n)
   assert np.array_equal(rel@y if term['coset_side']=='left' else y@rel,w)
   assert set(term['relative_word'])<=set(term['parabolic_nodes'])
   if len(term['parabolic_nodes'])<=6:finite_small(term['parabolic_nodes'])
   else:check_large_correction(term,w,y)
  assert not any(a.values()),('product',i)
 known.add(i);checks.append(i)
receipt={'status':'PASS','independent_engine':'Python integer root matrices and Laurent polynomial dictionaries','input':input_path.name,'positive_roots':len(positive),'bar_invariant_canonical_vectors':len(vectors),'dag_nodes_verified':checks,'multiplication_identities':len(checks)-1,'all_coset_witnesses_verified':True,'seconds':round(time.time()-start,3)}
input_path.with_name(input_path.stem+'_independent_verification.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
