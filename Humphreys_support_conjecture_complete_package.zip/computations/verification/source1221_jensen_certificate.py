import os
from pathlib import Path
from functools import lru_cache
from collections import defaultdict
import json,time
import numpy as np
from scipy.sparse import csr_matrix
ROOT=Path(os.environ['HUMPHREYS_DATA_DIR'])
OUT=Path(os.environ['HUMPHREYS_RESULT_DIR'])
class Spherical:
 def __init__(self,n,J):
  self.n=n;self.J=J;self.I=np.eye(n,dtype=np.int16);self.C=2*self.I.copy()
  for a,b in [(1,3),(3,4),(2,4),(4,5),(5,6),(6,7),(7,8)]:
   if b<=n:self.C[a-1,b-1]=self.C[b-1,a-1]=-1
  self.R=[]
  for s in range(n):
   A=self.I.copy();A[s,:]-=self.C[s,:];self.R.append(A)
  rr={tuple(map(int,self.I[:,i])) for i in range(n)};todo=list(rr)
  while todo:
   a=todo.pop()
   for R in self.R:
    b=tuple(map(int,R@a))
    if b not in rr:rr.add(b);todo.append(b)
  self.positive=np.array([a for a in rr if all(z>=0 for z in a)],dtype=np.int16).T
  assert self.positive.shape[1]==(63 if n==7 else 120)
  self.identity=self.I.tobytes()
 def matrix(self,k):return np.frombuffer(k,dtype=np.int16).reshape(self.n,self.n)
 def key(self,word):
  A=self.I.copy()
  for s in word:A=A@self.R[s-1]
  return A.tobytes()
 @lru_cache(None)
 def length(self,k):return int(np.all(self.matrix(k)@self.positive<=0,axis=0).sum())
 @lru_cache(None)
 def action(self,s,k):
  A=self.R[s-1]@self.matrix(k)
  while True:
   j=next((j for j in self.J if np.all(A[:,j-1]<=0)),None)
   if j is None:return A.tobytes()
   A=A@self.R[j-1]
 def mul(self,s,V):
  Z=defaultdict(int)
  for (k,e),c in V.items():
   j=self.action(s,k)
   if j==k:Z[k,e+1]+=c;Z[k,e-1]+=c
   else:
    Z[j,e]+=c;Z[k,e+(1 if self.length(j)>self.length(k) else -1)]+=c
  return {k:c for k,c in Z.items() if c}
 @lru_cache(None)
 def canon(self,k):
  if k==self.identity:return {(k,0):1}
  l=self.length(k)
  s=next(s for s in range(1,self.n+1) if self.length(self.action(s,k))==l-1)
  Z=defaultdict(int,self.mul(s,self.canon(self.action(s,k))))
  assert Z[k,0]==1 and all(e>=0 for (_,e),c in Z.items() if c)
  lowers=sorted({j for (j,e),c in Z.items() if j!=k and c},key=self.length,reverse=True)
  for j in lowers:
   c=Z.get((j,0),0)
   if c:
    for t,a in self.canon(j).items():Z[t]-=c*a
  Z={t:c for t,c in Z.items() if c}
  assert all(c>0 and (e>0 or j==k) for (j,e),c in Z.items())
  return Z
 def compare(self,word,terms):
  k=self.key(word);assert self.length(k)==len(word)
  V=self.canon(k);expected=defaultdict(int)
  for (j,e),c in V.items():expected[j]+=c
  actual={self.key(t['word']):int(t['coefficient']) for t in terms}
  assert actual==expected,('mismatch',len(actual),len(expected))
  return V

import csv,re
rows={int(r['index']):r for r in csv.DictReader((ROOT/'E8_A7_short_sources.tsv').open(),delimiter='\t')}
S=Spherical(8,[1,3,4,5,6,7,8])
bykey={S.key(list(map(int,r['coset_word'].split(','))) if r['coset_word'] else []):i for i,r in rows.items()}
chain=[];i=1221
while i!=1:
 r=rows[i];m=re.fullmatch(r'ERT_left_(\d+)_from_(\d+)',r['witness']);assert m,r
 chain.append((i,int(m[1]),int(m[2])));i=int(m[2])
chain.reverse();out=[]
for target,s,pred in chain:
 x=rows[target];z=rows[pred]
 xword=list(map(int,x['coset_word'].split(',')));zword=list(map(int,z['coset_word'].split(','))) if z['coset_word'] else []
 xkey=S.key(xword);zkey=S.key(zword)
 assert np.array_equal(S.R[s-1]@S.matrix(zkey),S.matrix(xkey))
 assert S.length(xkey)==S.length(zkey)+1
 V=defaultdict(int,S.mul(s,S.canon(zkey)))
 for t,c in S.canon(xkey).items():V[t]-=c
 V={t:c for t,c in V.items() if c};lower=[]
 while V:
  k=max({k for k,e in V},key=S.length);c=V.get((k,0),0);assert c>0,(target,bykey.get(k),c)
  for t,a in S.canon(k).items():V[t]=V.get(t,0)-c*a
  V={t:c for t,c in V.items() if c}
  js=[j for j in range(1,9) if np.array_equal(S.R[j-1]@S.matrix(k),S.matrix(zkey))]
  assert len(js)==1,(target,bykey.get(k),js)
  j=js[0];assert j!=s
  assert S.length(zkey)==S.length(k)+1
  assert np.array_equal(S.R[s-1]@S.R[j-1]@S.matrix(k),S.matrix(xkey))
  lower.append({'index':bykey[k],'word':rows[bykey[k]]['coset_word'],'coefficient':c,'weak_simple':j,'common_left_parabolic':sorted([s,j])})
 out.append({'target':target,'target_word':xword,'simple':s,'predecessor':pred,'predecessor_word':zword,'lower':lower,'canonical_terms':len({k for k,e in S.canon(xkey)})})
ans={'seed':{'index':1,'coset_word':[],'proof':'finite parabolic longest element'},'J':[1,3,4,5,6,7,8],'target':1221,'steps':out,'total_steps':len(out),'total_corrections':sum(len(x['lower']) for x in out),'prime_range':'p>3 suffices for every rank-two common-coset comparison','status':'EXACT_JENSEN_PROOF'}
(OUT/'source1221_jensen_certificate.json').write_text(json.dumps(ans,indent=2)+'\n')
print(json.dumps(ans))
