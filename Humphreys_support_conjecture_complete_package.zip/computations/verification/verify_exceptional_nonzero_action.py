import os
"""Independently connect a certified KL vector to a nonzero finite-W action."""
import json,sys,time,tomllib,hashlib
from pathlib import Path
from functools import lru_cache
import numpy as np
from scipy.sparse import csr_matrix,eye
started=time.time();source=Path(sys.argv[1]);dagfile=Path(sys.argv[2])
d=json.loads(source.read_text());dag=json.loads(dagfile.read_text())
prior=json.loads(dagfile.with_name(dagfile.stem+'_independent_verification.json').read_text())
assert prior['status']=='PASS'
n=d['dimension'];q=d['auxiliary_prime'];R=[]
for entries in d['sparse_generators']:
 a=np.asarray(entries,dtype=np.int64)
 R.append(csr_matrix((a[:,2],(a[:,0]-1,a[:,1]-1)),shape=(n,n)))
I=eye(n,format='csr',dtype=np.int64)
edges={(1,3),(3,4),(2,4),(4,5),(5,6),(6,7),(7,8)}
norm=max(int(np.max(abs(x).sum(axis=1))) for x in R)
assert norm**6<2**62 and q*norm<2**62
for i,x in enumerate(R):
 z=x@x-I;z.eliminate_zeros();assert z.nnz==0
 for j in range(i):
  m=3 if (j+1,i+1) in edges else 2
  a=x@R[j];z=I
  for _ in range(m):z=z@a
  z=z-I;z.eliminate_zeros();assert z.nnz==0
def apply(word,v):
 for s in reversed(word):v=(R[s-1]@v)%q
 return v
v=np.asarray(d['seed_vector'],dtype=np.int64)
for factor in d['parabolic_coset_factors']:
 v=sum((apply(word,v) for word in factor),np.zeros(n,dtype=np.int64))%q
assert np.array_equal(v,np.asarray(d['invariant_vector'])%q)
assert all(np.array_equal((R[s-1]@v)%q,v) for s in d['parabolic_nodes'])
out=np.zeros(n,dtype=np.int64)
for term in d['terms']:out=(out+int(term['coefficient'])*apply(term['word'],v))%q
assert np.array_equal(out,np.asarray(d['result_vector'])%q)
assert out[d['nonzero_coordinate']-1]==d['nonzero_value']!=0
# Match every coefficient and Weyl word against the separately certified KL vector.
m=dag['rank'];ident=np.eye(m,dtype=np.int16);cartan=2*ident.copy();rootm=[]
for a,b in edges:
 if max(a,b)<=m:cartan[a-1,b-1]=cartan[b-1,a-1]=-1
for s in range(m):
 x=ident.copy();x[s,:]-=cartan[s,:];rootm.append(x)
def groupkey(word):
 x=ident.copy()
 for s in word:x=x@rootm[s-1]
 return tuple(map(int,x.reshape(-1)))
target=next(x for x in dag['canonical_vectors'] if x['index']==d['source_index'])
expected={groupkey(t['coset_word']):sum(c for e,c in t['polynomial']) for t in target['terms']}
actual={groupkey(t['word']):int(t['coefficient']) for t in d['terms']}
assert actual==expected
assert d['parabolic_nodes']==dag['parabolic_J']
rep_match=None
repfile=source.with_name('E8_phi1050_positive_rep.toml')
if n==1050:
 rep=tomllib.loads(repfile.read_text());assert rep['sparse_generators']==d['sparse_generators']
 charreceipt=json.loads(source.with_name('E8_phi1050_independent_character_receipt.json').read_text())
 assert charreceipt['integral_coxeter_relations'] and charreceipt['all_class_traces']
 assert hashlib.sha256(repfile.read_bytes()).hexdigest()==charreceipt['representation_sha256']
 rep_match='existing independent 112-class integral character identification'
receipt=dict(status='PASS',input=source.name,dag=dagfile.name,dimension=n,
 integral_coxeter_relations=True,parabolic_invariant_vector_recomputed=True,
 all_KL_terms_match_independent_DAG=True,terms=len(actual),auxiliary_prime=q,
 nonzero_coordinate=d['nonzero_coordinate'],nonzero_value=int(out[d['nonzero_coordinate']-1]),
 character_identification=rep_match,seconds=round(time.time()-started,3))
source.with_name(source.stem+'_independent_verification.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
