import os
from pathlib import Path
from collections import deque,Counter
import json,tomllib
import numpy as np
from scipy.sparse import csr_matrix
ROOT=Path(os.environ['HUMPHREYS_DATA_DIR'])
OUT=Path(os.environ['HUMPHREYS_RESULT_DIR'])
q=1000003;n=175;I=np.eye(n,dtype=np.int64)
r=tomllib.loads((ROOT/'E8_phi175_positive_rep.toml').read_text());R=[]
for entries in r['sparse_generators']:
 a=np.asarray(entries,dtype=np.int64);R.append(csr_matrix((a[:,2],(a[:,0]-1,a[:,1]-1)),shape=(n,n)))
C=2*np.eye(8,dtype=np.int64)
for a,b in [(1,3),(3,4),(2,4),(4,5),(5,6),(6,7),(7,8)]:C[a-1,b-1]=C[b-1,a-1]=-1
theta=np.array([2,3,4,6,5,4,3,2],dtype=np.int64);beta=theta.copy();descent=[]
while beta.sum()>1:
 s=next(s for s in range(8) if (C@beta)[s]>0);beta[s]-=(C@beta)[s];descent.append(s+1)
j=int(np.flatnonzero(beta)[0])+1;word=descent+[j]+list(reversed(descent))
A=I.copy()
for s in reversed(word):A=(R[s-1]@A)%q
R0=A
assert np.array_equal(R0@R0%q,I)
D=[x.toarray()%q for x in R]
def product(a,b):return a@b%q
def signS3(a,b):return (I-a-b+product(a,b)+product(b,a)-product(product(a,b),a))%q
P=signS3(D[7],R0);assert np.array_equal(P@P%q,6*P%q)
P2=signS3(D[0],D[2]);P2=product(P2,(I-D[1])%q);assert np.array_equal(P2@P2%q,12*P2%q)
def rank_projector(P,size):
 d=int(np.trace(P)%q)*pow(size,-1,q)%q;assert d<=n;return d
print('E6 A2 sign multiplicity-space dimension',rank_projector(P,6),flush=True)
print('A5 A2 A1 sign multiplicity-space dimension',rank_projector(P2,12),flush=True)
report={'highest_root':theta.tolist(),'highest_root_reflection_word':word,'E6_A2_sign_space_dimension':rank_projector(P,6),'A5_A2_A1_sign_space_dimension':rank_projector(P2,12)}
for key,proj,size,gens in [('E6',P,6,D[:6]),('A5',P2,12,[D[4],D[5],D[6],D[7],R0])]:
 tr=[]
 for g in gens:
  t=int(np.trace(product(g,proj))%q)*pow(size,-1,q)%q
  if t>q//2:t-=q
  tr.append(t)
 report[key+'_simple_traces']=tr
print(json.dumps(report),flush=True)
(OUT/'independent_last_two_restrictions_initial.json').write_text(json.dumps(report,indent=2)+'\n')

def rref(A):
 A=np.array(A,dtype=np.int64,copy=True)%q;row=0;piv=[]
 for col in range(A.shape[1]):
  hits=np.flatnonzero(A[row:,col])
  if not len(hits):continue
  k=row+int(hits[0]);A[[row,k]]=A[[k,row]];A[row]=A[row]*pow(int(A[row,col]),-1,q)%q
  for k in range(A.shape[0]):
   if k!=row and A[k,col]:A[k]=(A[k]-A[k,col]*A[row])%q
  piv.append(col);row+=1
  if row==A.shape[0]:break
 return A,piv

def restricted(P,size,gens):
 d=rank_projector(P,size);_,cols=rref(P);assert len(cols)==d;B=P[:,cols]
 _,rows=rref(B.T);assert len(rows)==d
 minor=B[rows,:];aug,piv=rref(np.hstack([minor,np.eye(d,dtype=np.int64)]));assert piv==list(range(d))
 inv=aug[:,d:];ans=[]
 for g in gens:
  assert np.array_equal(product(g,P),product(P,g))
  gB=product(g,B);a=product(inv,gB[rows]);assert np.array_equal(product(B,a),gB);ans.append(a)
 E=np.eye(d,dtype=np.int64);eq=np.vstack([np.kron(E,a)-np.kron(a.T,E) for a in ans])
 _,piv=rref(eq);assert d*d-len(piv)==1
 return ans,d
E6,d6=restricted(P,6,D[:6]);A5,d5=restricted(P2,12,[D[4],D[5],D[6],D[7],R0])
report['E6_characteristic_zero_commutant_dimension']=1
report['A5_characteristic_zero_commutant_dimension']=1
report['irreducibility_justification']='Finite-group representations are semisimple in characteristic zero. Modular commutant nullity 1 bounds rational nullity above by 1, hence proves irreducibility.'
# Independent Specht character via the Murnaghan--Nakayama rule.
from functools import lru_cache
@lru_cache(None)
def parts(n,m=None):
 if n==0:return ((),)
 if m is None:m=n
 return tuple((i,)+t for i in range(min(n,m),0,-1) for t in parts(n-i,i))
def cells(lam):return {(i,j) for i,a in enumerate(lam) for j in range(a)}
@lru_cache(None)
def char(lam,cycle):
 if not cycle:return 1 if not lam else 0
 k=cycle[0];total=0;big=cells(lam)
 for mu in parts(sum(lam)-k):
  small=cells(mu)
  if not small<=big:continue
  rim=big-small
  if any({(i,j),(i+1,j),(i,j+1),(i+1,j+1)}<=rim for i,j in rim):continue
  seen={next(iter(rim))};todo=list(seen)
  while todo:
   i,j=todo.pop()
   for pt in [(i+1,j),(i-1,j),(i,j+1),(i,j-1)]:
    if pt in rim and pt not in seen:seen.add(pt);todo.append(pt)
  if seen!=rim:continue
  total+=(-1)**(len({i for i,j in rim})-1)*char(mu,cycle[1:])
 return total
traces=[]
for cycle in parts(6):
 perm=list(range(6));a=0
 for k in cycle:
  for b in range(a,a+k):perm[b]=a+(b-a+1)%k
  a+=k
 # Bubble permutation to identity by right adjacent transpositions, reverse for a word.
 cur=perm[:];word=[]
 for i in range(6):
  j=cur.index(i)
  while j>i:cur[j-1],cur[j]=cur[j],cur[j-1];word.append(j-1);j-=1
 M=np.eye(d5,dtype=np.int64)
 for s in reversed(word):M=product(M,A5[s])
 t=int(np.trace(M)%q);t=t-q if t>q//2 else t
 expected=char((2,2,2),cycle);assert t==expected,(cycle,t,expected)
 traces.append({'cycle_type':cycle,'trace':t})
report['A5_all_11_class_traces']=traces
report['positive_restrictions']=[{'centralizer':'E6+A2','projected_small_factor':'sign(A2)','residual_dimension':10,'residual_irreducible':True,'residual_label':'phi10,9 (unique E6 character of degree 10)','multiplicity':1},{'centralizer':'A5+A2+A1','projected_small_factors':'sign(A2) tensor sign(A1)','residual_dimension':5,'residual_irreducible':True,'residual_label':'Specht(2,2,2)','multiplicity':1}]
report['ordinary_restrictions']=[{'vertex':4,'local_index':9,'local_character':'phi10,9,3','multiplicity':1},{'vertex':9,'local_index':62,'local_character':'3,2,33','multiplicity':1}]
report['label_conversion']='Positive matrices phi175,12 are determinant twists of ordinary phi175,36. Determinant restriction is determinant of each full-rank factor; E6 degree-10 is self-twist, A5 Specht(222) twists to Specht(33).'
report['auxiliary_prime']=q
report['status']='PASS'
(OUT/'independent_last_two_restrictions.json').write_text(json.dumps(report,indent=2)+'\n')
print('INDEPENDENT_LAST_TWO_RESTRICTIONS_PASS',flush=True)
