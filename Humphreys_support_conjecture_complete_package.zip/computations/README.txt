COMPUTATIONAL SUPPLEMENT
The Humphreys support conjecture
Qiyue Tang
November 12, 2026
tangqy24@mails.tsinghua.edu.cn

1. Contents and mathematical scope

This supplement preserves the finite exceptional data used in the article
and provides exact arithmetic verification programs. The mathematical
arguments establishing support bounds, source independence in characteristic
p, the classical families, and the geometric identification of intersection
forms are in the article. Numerical nonzero actions alone do not establish
source independence, and a coverage count alone does not establish a support
formula.

data/exceptional_source_tables/ contains the supplied exceptional source,
Springer, character, restriction, orbit-order, and coverage tables, together
with root words, canonical vectors, finite matrix representations, serialized
Julia objects, and older intermediate receipts. The complete supplied table
directory is preserved so that intermediate tables referenced by the
verification code remain available. Older status fields may describe a
historical stage. In particular the historical source2794 action file with
"pending_source" in its name is an arithmetic input; its geometric source
independence is proved in the article. The final E8 tables are the nine-vertex
geometric-complete tables and the associated per-vertex files.

verification/ contains portable Python verifier copies. Their changes from
the supplied programs and the subsequent independent computations are confined
to input/output path bindings and an os import. The arithmetic is unchanged.
Their paths are controlled by HUMPHREYS_DATA_DIR and HUMPHREYS_RESULT_DIR;
run_checks.py supplies these variables automatically.

recorded_results/ contains the results obtained during the mathematical review,
including the independent source1221 chain, exceptional DAGs, nonzero actions,
last two restrictions, coverage consistency, E8 localization calculations, and
the lattice/half-pair checks. These files document prior calculations. The
runner does not accept a recorded PASS as a substitute for executing a check.

julia/ contains unchanged original Julia programs and the recorded package
environment. The supplied Manifest.toml records Julia 1.11.9 and Chevie 0.1.15
(git tree 77ca5195a61865a5ee33d90b10e1d59571693139). This describes the original
package environment; it is not a claim that Julia was available or run during
the independent Python review.

provenance.json records source paths, original SHA-256 hashes, and path-only
changes. manifest.sha256 records hashes of the distributed supplement files.
New local runs under runs/ are intentionally outside this manifest.

table_generation/ preserves the final article's exceptional-table generator
and its table manifest. original_generate_exceptional_tables.py is the unchanged
archival copy with manuscript-workspace paths. The portable entry point
generate_exceptional_tables.py reads the same data and recorded source words,
and accepts a new output directory:

    python3 table_generation/generate_exceptional_tables.py /path/to/new/tables

It generates the source-word, source1221, DAG, selected-block, and all 919
required-witness TeX tables. This is formatting and table selection from
explicit arithmetic records, not an independent proof of their contents.

2. Python requirements and commands

Use Python 3.11 or newer with numpy, scipy, and sympy. For a fresh virtual
environment, install the packages listed in requirements.txt. Each run reports
the actual Python and package versions it used; no version is silently assumed.

    python3 -m pip install -r requirements.txt
    python3 run_checks.py --list
    python3 run_checks.py --quick
    python3 run_checks.py --full

The default is --quick. It checks coverage-table consistency, reconstructs the
25-step source1221 chain, computes the five origin localization integrals, and
identifies the 50-dimensional representation on all 112 conjugacy classes.

--full runs all supported Python checks, including the ten source DAGs, the
50-, 175-, and 1050-dimensional representations, their selected nonzero actions,
the final two restrictions, and both E8 localization computations. It can take
several minutes. It does not run the Julia/CHEVIE coverage pipeline.

For selected checks:

    python3 run_checks.py --checks rank3,restrictions175
    python3 run_checks.py --checks action50,action1050

Necessary prerequisite checks are scheduled automatically. The runner validates
the distribution manifest, creates a new output directory, copies the data,
removes old independent receipts from that copy, and executes each verifier.
It never writes into the distributed data directory. Logs and a run_report.json
are retained, together with fresh receipts. A successful run removes its large
working data copy unless --keep-data was passed. If a check fails, the runner
stops, returns a nonzero exit code, and retains the working data for diagnosis.
Use --output PATH to choose a new output directory. An existing directory is
never overwritten. --skip-manifest is available only for deliberate local edits.

3. What the Python checks establish

The DAG verifier uses integer root matrices and Laurent polynomial dictionaries.
It checks reduced words, bar invariance, triangularity, canonical vectors,
multiplication identities, relative words, and the rank/coset conditions of the
source propagation arguments. The ten DAGs contain 220 nodes and 210 nontrivial
multiplication identities. The additional source1221 reconstruction gives
25 steps and 23 lower corrections. Characteristic-p conclusions use the
published small-rank and common-coset results stated in the article.

The representation programs check integral Coxeter relations and all class
traces. Their auxiliary prime exceeds twice the representation dimension;
the integral trace bound makes the modular trace comparison exact. Nonzero
actions are tied to the separately reconstructed canonical vectors. The
source2794 action is kept logically separate from its geometric p-independence.

The last two restriction calculations use explicit 175-dimensional matrices,
small-factor sign projectors, commutant ranks, and the Murnaghan--Nakayama rule.
They give multiplicity one for the E6+A2 and A5+A2+A1 representations appearing
in the final two E8 coverage rows. The auxiliary prime is used as an exact
rank certificate and for bounded integral character comparisons.

The localization programs perform rational arithmetic. The origin computation
gives 18, 12, 6, 0, 0. The rank-three computation gives 1, -3, 9, 6. Their
interpretation as the actual intersection forms, including the Fourier dual
convention and integral lattices, is proved separately in the article.

The coverage consistency program verifies source keys, orbit-bound inclusion,
central support intersections from the supplied cut tables, matching detailed
witness rows, final concatenation, and the two geometric replacements. It
confirms 352 required E7 generators and 567 required E8 generators. It is not
an independent recomputation of every noncentral CHEVIE restriction multiplicity
or every local Richardson-cut table. Those bulk arrays were checked through
their source programs and row consistency; they were not independently rerun
in the Python review. Nontrivial local-system rows outside the required set do
not enter the trivial-local-system generator criterion proved in the article.

4. Original Julia/CHEVIE reproduction

The original Julia sources use a mixture of paths relative to the source file
and paths beginning with humphreys/compute/. The preparation program recreates
that relative layout without modifying the original sources:

    python3 prepare_julia.py /path/to/new/julia-work

It prints commands to instantiate the recorded environment and run the E7 and
E8 upgraded coverage stages. Package installation can require network access.
The prepared working directory is isolated from the distributed inputs.

The principal programs defining the finite trace computation and source/cut
selection are:

    exceptional_positive_source_coverage.jl
    exceptional_all_affine_sources.jl
    exceptional_upgraded_finite_sources.jl
    exceptional_richardson_retention.jl
    exceptional_semisimple_trace_coverage.jl

The E8 refinement stages are preserved in:

    exceptional_incremental_closed_point.jl
    exceptional_incremental_direct_closed_points.jl
    exceptional_maximal_final_coverage.jl
    exceptional_phi175_missing_germs.jl

The two run_e*_upgraded_coverage.jl entry points regenerate the upgraded stages;
they do not by themselves claim to regenerate all later refinements or the
geometric theorem. The later sources contain their actual callable functions
and record-specific entry points. Consult the article's finite source tables,
the source keys, and the supplied final coverage TSVs when composing a complete
Julia rerun. The original Julia programs and their preserved results have not
been relabeled as independently reproduced results.

5. Reading the final exceptional tables

E7 required rows are in E7_semisimple_1_upgraded_coverage.tsv through
E7_semisimple_8_upgraded_coverage.tsv.

E8_nine_vertex_geometric_complete_status.json names the nine final per-vertex
tables. E8_nine_vertex_geometric_complete_coverage.tsv is their concatenation.
The required rows are exactly those with trivial_local_system = true.
E8_final_all_actual_sources.tsv contains the final source key records.
The article gives the Weyl words, source propagation identities, local witness
rows, and the conventions needed to interpret these identifiers.

Historical receipt fields are not the definition of the theorem or its proof.
The article, its explicit source constructions, the exact verification rules,
and the final specified tables supply the mathematical dependencies.
