# Independent minimal proof DAG: rank<=6 partial-Levi seeds + Jensen only.
# This intentionally does not use any ERT flags in the input .jls file.
using Chevie, Serialization, TOML
const vv=Pol()
const VP=typeof(vv)
tomlify(x::NamedTuple)=Dict(string(k)=>tomlify(v) for (k,v) in pairs(x))
tomlify(x::AbstractVector)=tomlify.(x)
tomlify(x)=x
function add!(a,i,q)
 z=get(a,i,zero(vv))+q
 if iszero(z);delete!(a,i);else;a[i]=z;end
end
function main()
 n=parse(Int,ARGS[1]);tag=ARGS[2];target=parse(Int,ARGS[3])
 d=deserialize("humphreys/compute/exceptional_source_tables/E$(n)_$(tag)_short_sources.jls")
 W=coxgroup(:E,n);H=reflection_subgroup(W,d.J);wJ=longest(H)
 known=falses(length(d.xs));proof=Dict{Int,Any}()
 function product(s,z)
  a=Dict{Int,VP}()
  for(i,c)in d.canonical[z]
   j=d.acts[s,i];@assert j>0
   if j==i;add!(a,i,(vv+vv^-1)*c)
   else;add!(a,j,c);add!(a,i,(d.lens[j]>d.lens[i] ? vv : vv^-1)*c)
   end
  end
  a
 end
 function lower(s,z,i)
  a=product(s,z)
  for(k,q)in d.canonical[i];add!(a,k,-q);end
  c=Pair{Int,Int}[]
  for y=i-1:-1:1
   q=get(a,y,zero(vv));iszero(q)&&continue
   @assert degree(q)==0 && valuation(q)==0 && q[0]>0
   push!(c,y=>q[0])
   for(k,r)in d.canonical[y];add!(a,k,-q*r);end
  end
  @assert isempty(a)
  c
 end
 # The single additional rank-seven upper element is source49 in E7/A6.
 upper49=prod(W.([1,3,1,4,3,1,5,4,2,3,1,4,5,6,5,4,2,3,1,4,3,5,4,6,5,7,6,5,4,3,1]))
 function right_factor(g,I)
  u=g;b=one(W)
  while true
   ss=findfirst(s->isrightdescent(W,u,s),I);isnothing(ss)&&return b
   t=I[ss];u=u*W(t);b=W(t)*b
  end
 end
 function cosetproof(i,y,m)
  wi=d.xs[i]*wJ;wy=d.xs[y]*wJ
  for(side,g)in [("left",wi*inv(wy)),("right",inv(wy)*wi)]
   rw=word(W,g);I=sort(unique(rw));ref="finite_rank_le6";uw=Int[]
   good=length(I)<=6
   if !good && I==collect(1:7)
    b=right_factor(side=="left" ? inv(wi) : wi,I)
    if b==upper49 || b==inv(upper49)
     good=true;ref=b==upper49 ? "E7_A6_source49" : "E7_A6_source49_inverse";uw=word(W,b)
    end
   end
   good && return (lower=y,multiplicity=m,coset_side=side,parabolic_nodes=I,relative_word=rw,
      lower_full_word=word(W,wy),upper_certificate=ref,upper_word=uw)
  end
  nothing
 end
 for i=1:target
  I=sort(unique(word(W,d.xs[i])))
  if length(I)<=6
   known[i]=true;proof[i]=(index=i,method="partial_Levi_rank_le6",parabolic_nodes=I,
     intersection_J=intersect(I,d.J),coset_word=word(W,d.xs[i]),full_word=word(W,d.xs[i]*wJ))
   continue
  end
  if n==8 && tag=="D6" && !(1 in word(W,d.xs[i]*wJ))
   known[i]=true;proof[i]=(index=i,method="D7_D6_minuscule",parabolic_nodes=collect(2:8),
     intersection_J=d.J,coset_word=word(W,d.xs[i]),full_word=word(W,d.xs[i]*wJ))
   continue
  end
  for s=1:n
   z=d.acts[s,i];(0<z<i && known[z])||continue
   cc=lower(s,z,i);pr=[cosetproof(i,y,m) for(y,m)in cc]
   all(!isnothing,pr)||continue
   @assert W(s)*d.xs[z]==d.xs[i]
   known[i]=true;proof[i]=(index=i,method="Jensen_coset",simple=s,predecessor=z,
      coset_word=word(W,d.xs[i]),full_word=word(W,d.xs[i]*wJ),corrections=pr)
   break
  end
 end
 @assert known[target]
 dag=Int[];i=target
 while true
  push!(dag,i);pr=proof[i];pr.method!="Jensen_coset"&&break;i=pr.predecessor
 end
 reverse!(dag)
 used=Set(dag)
 for i in dag
  pr=proof[i]
  if pr.method=="Jensen_coset";for c in pr.corrections;push!(used,c.lower);end;end
 end
 vectors=[]
 for i in sort(collect(used))
  push!(vectors,(index=i,terms=[(index=y,coset_word=word(W,d.xs[y]),
   polynomial=[[e,q[e]] for e in valuation(q):degree(q) if q[e]!=0]) for(y,q)in sort(collect(d.canonical[i]))]))
 end
 receipt=(rank=n,parabolic_J=d.J,p_range="prime p > 7",target=target,
   rule="partial-Levi rank<=6 seed plus Jensen, with only extra upper E7/A6 source49; no ERT or minuscule input",
   dag=dag,nodes=[proof[i] for i in dag],canonical_vectors=vectors)
 out="humphreys/compute/exceptional_source_tables/E$(n)_$(tag)_source$(target)_rank7_dag.toml"
 open(out,"w")do io;TOML.print(io,tomlify(receipt));end
 println("CERTIFIED",count(known)," DAG",dag)
 for i in dag;println(proof[i]);end
end
main()
