# Associated induction from the E6/A5 contact Schubert divisor, using the
# existing E8/A7 spherical module. This is the 28-term Grassmannian induction,
# not the 12-step Bott--Samelson convolution.
using Chevie, Serialization, TOML
const v=Pol(); const VP=typeof(v); const Vec=Dict{Int,VP}
function add!(a,i,p)
 q=get(a,i,zero(v))+p
 if iszero(q);delete!(a,i);else;a[i]=q;end
end
function main()
 base=joinpath(@__DIR__,"exceptional_source_tables")
 d=deserialize(joinpath(base,"E8_A7_short_sources.jls"))
 W=coxgroup(:E,8); J=d.J; K=[1,3,4,5,6,8]
 source=509; w=d.xs[source]*longest(reflection_subgroup(W,J))
 @assert all(s->isleftdescent(W,w,s),K)
 us=[one(W)]; ids=Dict(one(W)=>1);at=1
 while at<=length(us)
  for s in J
   u=W(s)*us[at]
   any(j->isrightdescent(W,u,j),K)&&continue
   if !haskey(ids,u);push!(us,u);ids[u]=length(us);end
  end
  at+=1
 end
 @assert length(us)==28
 maxlen=maximum(u->length(W,u),us);@assert maxlen==12
 function standard_product(s,z)
  a=Vec()
  for(i,c)in z
   j=d.acts[s,i];@assert j>0
   if j==i;add!(a,i,v^-1*c)
   else
    add!(a,j,c)
    d.lens[j]<d.lens[i]&&add!(a,i,(v^-1-v)*c)
   end
  end
  a
 end
 ans=Vec()
 for u in us
  a=copy(d.canonical[source])
  for s in reverse(word(W,u));a=standard_product(s,a);end
  for(i,c)in a;add!(ans,i,v^(maxlen-length(W,u))*c);end
 end
 decomposition=Pair{Int,VP}[]
 for i=length(d.xs):-1:1
  c=get(ans,i,zero(v));iszero(c)&&continue
  push!(decomposition,i=>c)
  for(y,p)in d.canonical[i];add!(ans,y,-c*p);end
 end
 @assert isempty(ans)
 rows=[]
 for(i,c)in decomposition
  @assert all(e->c[e]>=0,valuation(c):degree(c))
  @assert all(e->c[e]==c[-e],valuation(c):degree(c))
  println("TERM ",i," length ",d.lens[i]," certified ",d.known[i]," coefficient ",c," Euler ",c(1))
  push!(rows,Dict("index"=>i,"coset_length"=>d.lens[i],"certified"=>d.known[i],
   "coefficient"=>string(c),"powers"=>[e for e=valuation(c):degree(c) if c[e]!=0],
   "coefficients"=>[Int(c[e]) for e=valuation(c):degree(c) if c[e]!=0],
   "Euler"=>Int(c(1))))
 end
 @assert first(decomposition).first==2794
 open(joinpath(base,"E8_E6_contact_A7_induction.toml"),"w")do io
  TOML.print(io,Dict("source"=>source,"J"=>J,"K"=>K,"Grassmannian_cosets"=>length(us),
   "decomposition"=>rows))
 end
end
main()
