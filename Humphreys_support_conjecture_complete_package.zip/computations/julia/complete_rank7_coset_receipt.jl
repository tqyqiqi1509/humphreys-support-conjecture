using Chevie,TOML
function main()
 p="humphreys/compute/exceptional_source_tables/E8_A7_source2611_rank7_dag.toml"
 d=TOML.parsefile(p);W=coxgroup(:E,8)
 elem(word)=isempty(word) ? one(W) : prod(W.(word))
 x49=[4,3,1,5,4,3,6,5,4,2];J49=[1,3,4,5,6,7];I49=collect(1:6)
 b49=elem(x49)*longest(reflection_subgroup(W,J49))
 count=0
 for node in d["nodes"]
  node["method"]=="Jensen_coset"||continue
  for c in node["corrections"]
   startswith(c["upper_certificate"],"E7_A6_source49")||continue
   wi=elem(node["full_word"]);wy=elem(c["lower_full_word"])
   inverse=c["coset_side"]=="left"
   ww=inverse ? inv(wi) : wi;yy=inverse ? inv(wy) : wy
   b=elem(c["upper_word"]);u=ww*inv(b);a=inv(u)*yy;I=c["parabolic_nodes"]
   @assert all(!isrightdescent(W,u,s) for s in I)
   @assert all(s in I for s in word(W,a))
   @assert length(W,ww)==length(W,u)+length(W,b)
   @assert length(W,yy)==length(W,u)+length(W,a)
   @assert b==b49 || b==inv(b49)
   c["jensen_applied_after_inversion"]=inverse
   c["common_minimal_right_coset_word"]=word(W,u)
   c["lower_parabolic_word"]=word(W,a)
   c["upper_source_coset_word"]=x49
   c["upper_source_J"]=J49
   c["upper_source_Levi_I"]=I49
   c["upper_source_Levi_K"]=intersect(I49,J49)
   c["upper_source_inverted"]=b==inv(b49) && b!=b49
   count+=1
  end
 end
 open(p,"w")do io;TOML.print(io,d);end
 println("EXPLICIT_RANK7_COSET_FACTORIZATIONS ",count)
end
main()
