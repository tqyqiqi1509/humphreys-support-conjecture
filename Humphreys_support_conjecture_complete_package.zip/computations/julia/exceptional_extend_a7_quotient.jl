# Extend the existing small A7 quotient only; preserve the original cache.
using Chevie, Serialization
const v=Pol();const PV=typeof(v);const VV=Dict{Int,PV}
function addterm!(a,i,p)
 z=get(a,i,zero(v))+p
 if iszero(z);delete!(a,i);else;a[i]=z;end
end
function main()
 base=joinpath(@__DIR__,"exceptional_source_tables")
 old=deserialize(joinpath(base,"E8_A7_short_sources.jls"))
 depth=isempty(ARGS) ? 36 : parse(Int,ARGS[1])
 W=coxgroup(:E,8);J=old.J;wJ=longest(reflection_subgroup(W,J))
 xs=copy(old.xs);lens=copy(old.lens);ids=Dict(x=>i for(i,x)in enumerate(xs))
 Nold=length(xs);at=1
 while at<=length(xs)
  x=xs[at]
  if old.depth<=lens[at]<depth
   for s=1:8
    z=W(s)*x
    any(j->isrightdescent(W,z,j),J)&&continue
    if !haskey(ids,z)
     @assert length(W,z)==lens[at]+1
     push!(xs,z);push!(lens,lens[at]+1);ids[z]=length(xs)
    end
   end
  end
  at+=1
 end
 @assert issorted(lens)
 n=length(xs);acts=zeros(Int,8,n)
 for i=1:n,s=1:8
  z=W(s)*xs[i]
  acts[s,i]=any(j->isrightdescent(W,z,j),J) ? i : get(ids,z,0)
 end
 function product(s,vec)
  a=VV()
  for(i,c)in vec
   j=acts[s,i];@assert j>0
   if j==i;addterm!(a,i,(v+v^-1)*c)
   else;addterm!(a,j,c);addterm!(a,i,(lens[j]>lens[i] ? v : v^-1)*c);end
  end
  a
 end
 canonical=Vector{VV}(undef,n);canonical[1:Nold]=old.canonical
 known=falses(n);known[1:Nold]=old.known
 witness=fill("",n);witness[1:Nold]=old.witness
 corr=copy(old.corrections)
 println("EXTEND ",Nold," to ",n," depth ",depth);flush(stdout)
 for i=Nold+1:n
  s=first(s for s=1:8 if 0<acts[s,i]<i);z=acts[s,i]
  a=product(s,canonical[z]);cc=Pair{Int,Int}[]
  @assert get(a,i,zero(v))==one(v)
  for y=i-1:-1:1
   c=get(a,y,zero(v));iszero(c)&&continue
   b=Pol(c[0])
   for e=valuation(c):-1;b+=c[e]*(v^e+v^-e);end
   if !iszero(b)
    @assert degree(b)==0&&b[0]>0
    push!(cc,y=>b[0]);for(k,q)in canonical[y];addterm!(a,k,-b*q);end
   end
  end
  @assert all(y==i||valuation(q)>0 for(y,q)in a)
  canonical[i]=a;corr[(s,z)]=cc
  if length(unique(word(W,xs[i])))<=6
   known[i]=true;witness[i]="Levi_partial_inflation_rank_le6_pgt7"
  end
  if i%100==0;println("CANONICAL ",i," / ",n);flush(stdout);end
 end
 out=joinpath(base,"E8_A7deep_short_sources.tsv")
 open(out,"w")do io
  println(io,"index\tcoset_length\tfull_length\tcertified\twitness\tcoset_word\tfull_word\tstandard_terms")
  for i=1:n
   w=xs[i]*wJ
   println(io,join((i,lens[i],length(W,w),known[i],witness[i],
     join(word(W,xs[i]),","),join(word(W,w),","),length(canonical[i])),"\t"))
  end
 end
 serialize(replace(out,".tsv"=>".jls"),(J=J,rank=8,depth=depth,xs=xs,lens=lens,
   acts=acts,canonical=canonical,known=known,witness=witness,corrections=corr))
 println("SAVED ",out," count ",n," certified ",count(known));flush(stdout)
end
main()
