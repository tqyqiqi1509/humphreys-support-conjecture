# Exact non-special block witness using a factored parabolic Reynolds sum.
using Chevie, Serialization, LinearAlgebra, SparseArrays, TOML
plain(x::NamedTuple)=Dict(string(k)=>plain(v) for(k,v)in pairs(x))
plain(x::AbstractVector)=plain.(x)
plain(x::BigInt)=string(x)
plain(x)=x
function main()
 label=length(ARGS)>0 ? ARGS[1] : "phi1050,34"
 W=coxgroup(:E,8);ci=charinfo(W);ct=CharTable(W);names=charnames(W)
 i=findfirst(==(label),names);@assert !isnothing(i)
 row=ct.irr[i,:].*ct.irr[ci.positionDet,:];j=findfirst(k->ct.irr[k,:]==row,axes(ct.irr,1))
 println("ORDINARY ",label," POSITIVE ",names[j]);flush(stdout)
 R=representation(W,j);N=size(R[1],1)
 println("RELATIONS ",isrepresentation(W,R)," DIM ",N," NNZ ",[nnz(r) for r in R]);flush(stdout)
 d=deserialize("humphreys/compute/exceptional_source_tables/E8_D6_short_sources.jls")
 function act(word,v)
  z=copy(v);for s in reverse(word);z=R[s]*z;end;z
 end
 # Chain of standard subgroups: each exact group sum is a product of
 # sums over minimal right cosets. No denominator or floating point.
 factors=[];prev=Int[]
 for a in d.J
  K=[prev;a];xs=[one(W)];seen=Set(xs);at=1
  while at<=length(xs)
   for s in K
    z=W(s)*xs[at]
    any(t->isrightdescent(W,z,t),prev)&&continue
    if !(z in seen);push!(xs,z);push!(seen,z);end
   end
   at+=1
  end
  push!(factors,[word(W,x) for x in xs]);prev=K
 end
 @assert prod(length.(factors))==order(reflection_subgroup(W,d.J))
 println("REYNOLDS_FACTORS ",length.(factors));flush(stdout)
 v=BigInt[mod(k*37+11,101)-50 for k=1:N];u=copy(v)
 for factor in factors
  z=zero(u);for word in factor;z+=act(word,u);end;u=z
 end
 @assert all(R[s]*u==u for s in d.J)
 println("INVARIANT_VECTOR_NONZERO ",!iszero(u)," SUMSQUARES ",sum(abs2,u));flush(stdout)
 @assert !iszero(u)
 U=Vector{Vector{BigInt}}(undef,length(d.xs));U[1]=u
 for k=2:length(d.xs)
  s=first(s for s=1:8 if 0<d.acts[s,k]<k);z=d.acts[s,k];U[k]=R[s]*U[z]
 end
 lines=readlines("humphreys/compute/exceptional_source_tables/E8_D6_short_cells.tsv")
 targets=sort([parse(Int,r[1]) for r in split.(lines[2:end],'\t') if length(r)>=9 && r[9]=="32" && r[4]=="true"])
 println("TARGETS ",targets);flush(stdout)
 hit=[]
 for idx in targets
  z=zeros(BigInt,N)
  for(y,q)in d.canonical[idx];z+=q(1).*U[y];end
  if !iszero(z)
   push!(hit,idx);nz=findfirst(!iszero,z)
   println("HIT ",idx," output_entry ",nz," value ",z[nz]," SUMSQUARES ",sum(abs2,z));flush(stdout)
   if length(hit)==1
    sparseR=[]
    for r in R
     a,b,c=findnz(r);push!(sparseR,[[a[k],b[k],c[k]] for k=eachindex(c)])
    end
    receipt=(ordinary_label=label,positive_label=names[j],dimension=N,index=idx,
      certified=d.known[idx],witness=d.witness[idx],coset_word=word(W,d.xs[idx]),
      full_word=word(W,d.xs[idx]*longest(reflection_subgroup(W,d.J))),
      sparse_generators=sparseR,seed_vector=v,parabolic_coset_factors=factors,
      parabolic_invariant_vector=u,result_vector=z,nonzero_coordinate=nz,
      nonzero_value=z[nz],sum_squares=sum(abs2,z),
      terms=[(word=word(W,d.xs[y]),coefficient=q(1)) for(y,q)in d.canonical[idx]])
    path="humphreys/compute/exceptional_source_tables/E8_$(replace(label,','=>'_'))_source$(idx)_receipt.toml"
    open(path,"w")do io;TOML.print(io,plain(receipt));end
   end
  else
   println("ZERO ",idx);flush(stdout)
  end
 end
 println("TOTAL_NONZERO ",length(hit)," / ",length(targets));flush(stdout)
end
main()
