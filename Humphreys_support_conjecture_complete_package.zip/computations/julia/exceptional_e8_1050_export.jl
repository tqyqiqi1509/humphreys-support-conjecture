using Chevie,LinearAlgebra,SparseArrays,TOML
function main()
W=coxgroup(:E,8);ci=charinfo(W);ct=CharTable(W)
names=charnames(W);i=findfirst(==("phi1050,34"),names);@assert !isnothing(i)
r=ct.irr[i,:].*ct.irr[ci.positionDet,:];j=findfirst(k->ct.irr[k,:]==r,axes(ct.irr,1))
println("TARGET ",i," ",names[i]," POSITIVE ",j," ",names[j]);flush(stdout)
R=representation(W,j);println("REP ",typeof(R)," size ",size(R[1])," eltype ",eltype(R[1])," nnz ",[nnz(r) for r in R]);flush(stdout)
data=Dict("ordinary_label"=>names[i],"positive_label"=>names[j],"dimension"=>size(R[1],1))
 mats=[]
 for r in R
  a,b,c=findnz(r);push!(mats,[[a[k],b[k],c[k]] for k=eachindex(c)])
 end
 data["sparse_generators"]=mats
 for (tag,J) in [("D6",[2,3,4,5,6,7]),("A7",[1,3,4,5,6,7,8])]
  factors=[];prev=Int[]
  for a in J
   K=[prev;a];xs=[one(W)];seen=Set(xs);at=1
   while at<=length(xs)
    for ss in K
     z=W(ss)*xs[at]
     any(t->isrightdescent(W,z,t),prev)&&continue
     if !(z in seen);push!(xs,z);push!(seen,z);end
    end
    at+=1
   end
   push!(factors,[word(W,x) for x in xs]);prev=K
  end
  @assert prod(length.(factors))==order(reflection_subgroup(W,J))
  data[tag*"_factors"]=factors;data[tag*"_J"]=J
 end
 open("humphreys/compute/exceptional_source_tables/E8_phi1050_positive_rep.toml","w")do io;TOML.print(io,data);end
 println("EXPORTED")
end
main()
