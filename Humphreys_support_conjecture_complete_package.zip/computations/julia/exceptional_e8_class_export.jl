using Chevie,TOML
function main()
 W=coxgroup(:E,8);ct=CharTable(W);names=charnames(W);label=isempty(ARGS) ? "phi50,8" : ARGS[1];j=findfirst(==(label),names)
 data=Dict("label"=>names[j],"dimension"=>Int(ct.irr[j,1]),
  "classes"=>[Dict("word"=>word(W,g),"trace"=>Int(ct.irr[j,k])) for(k,g)in enumerate(classreps(W))])
 open("humphreys/compute/exceptional_source_tables/E8_$(first(split(label,',')))_class_checks.toml","w")do io;TOML.print(io,data);end
 println("CLASS_WORDS_EXPORTED ",length(data["classes"]))
end
main()
