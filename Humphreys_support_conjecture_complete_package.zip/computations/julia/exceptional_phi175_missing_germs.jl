using Chevie,TOML
basepath=joinpath(@__DIR__,"exceptional_positive_source_coverage.jl")
include_string(Main,first(split(read(basepath,String),"E7_coverage=exceptional_sources(7)")),basepath)
Wsc=rootdatum(:E8);W=coxgroup(:E,8);rational_weyl_table!(W)
ys=quasi_isolated_reps(Wsc);ci=charinfo(W);U=UnipotentClasses(W);pg=U.springerseries[1][:locsys]
j=findfirst(==("phi175,36"),charnames(W));sj=family_special_map(W)[j];bound=pg[sj][1]
rows=[]
for (vertex,i,expected) in [(4,9,"phi10,9,3"),(9,62,"3,2,33")]
 M=centralizer(Wsc,ys[vertex]).group;rational_weyl_table!(M)
 @assert charnames(M)[i]==expected
 UM=UnipotentClasses(M);o=UM.springerseries[1][:locsys][i][1]
 ambient=findfirst(c->c.dynkin==induced_linear_form(Wsc,M,UM.classes[o].dynkin),U.classes)
 m=induction_table(M,W).scalar[j,i]
 push!(rows,Dict("vertex"=>vertex,"centralizer"=>isomorphism_type(M),"local_index"=>i,"local_character"=>expected,"ordinary_fullW_character"=>"phi175,36","multiplicity"=>m,"source_family_special"=>charnames(W)[sj],"source_bound"=>U.classes[bound].name,"target_bound"=>U.classes[ambient].name,"exact_target_bound"=>bound==ambient,"actual_source_status"=>"conditional_until_selected_p_canonical_source_certified"))
 println("PHI175_MISSING_GERM ",last(rows));flush(stdout)
end
open(joinpath(EXCEPTIONAL_OUTPUT,"E8_phi175_two_missing_germs.toml"),"w")do io;TOML.print(io,Dict("rows"=>rows));end
