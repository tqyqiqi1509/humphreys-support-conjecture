using Chevie
base=joinpath(@__DIR__,"exceptional_positive_source_coverage.jl")
include_string(Main,split(read(base,String),"\nE7_coverage=")[1],base)
ret=joinpath(@__DIR__,"exceptional_richardson_retention.jl")
include_string(Main,split(read(ret,String),"\nE7_retention=")[1],ret)
include("exceptional_upgraded_finite_sources.jl")
include("exceptional_semisimple_trace_coverage.jl")
W=coxgroup(:E,7);rational_weyl_table!(W)
E7_upgraded=all_affine_sources_upgraded((W=W,U=UnipotentClasses(W),ci=charinfo(W)),7)
E7_upgraded_central=richardson_retention(E7_upgraded,7;filetag="_upgraded")
E7_upgraded_vertices=Dict{Int,Any}()
for k in 1:8
  E7_upgraded_vertices[k]=exceptional_semisimple_coverage(E7_upgraded,7,k;filetag="_upgraded")
end
println("ALL_E7_CLOSED_POINTS_FINISHED")
