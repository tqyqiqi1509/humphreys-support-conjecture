using Chevie,TOML
W=coxgroup(:E,6);ct=CharTable(W);ns=charnames(W);ci=charinfo(W)
i=findfirst(==("phi10,9"),ns);v=findfirst(==("phi6,1"),ns)
x=ct.irr[i,:].*ct.irr[v,:]
rows=[]
for j in eachindex(ns)
 m=sum(ct.classes.*x.*ct.irr[j,:])/order(W)
 iszero(m)&&continue
 push!(rows,Dict("index"=>j,"label"=>ns[j],"multiplicity"=>Int(m),"b"=>ci.b[j]))
end
println(rows)
open("humphreys/compute/exceptional_source_tables/E6_phi10_derivative_tensor.toml","w") do io
 TOML.print(io,Dict("target"=>ns[i],"reflection"=>ns[v],"constituents"=>rows))
end
