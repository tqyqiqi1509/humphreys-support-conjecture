# Extend verified sources to ALL proper finite affine standard parabolics.
# Root projections that coincide are deduplicated only at the central germ1,
# where all affine translation cocycles are trivial. No claim at other germs.

function all_affine_sources(data,n)
    W,U,ci=data.W,data.U,data.ci; nw=length(ci.b)
    pairs=U.springerseries[1][:locsys]; om=incidence(U.orderclasses)
    simple=vcat(collect(1:n),[highest_short_root(W)])
    seen=Set{Tuple}(); seeds=[]; checked=0
    for mask in 0:(2^(n+1)-2)
        inds=[simple[j] for j in 1:n+1 if !iszero(mask & (1<<(j-1)))]
        H=reflection_subgroup(W,inds)
        key=Tuple(sort(inclusion(H,1:nref(H))))
        key in seen && continue
        push!(seen,key)
        selected,Kname=minuscule_seed_indices(H)
        hc=charinfo(H); sp=family_special_map(H)
        ind=induction_table(H,W).scalar; hn=charnames(H)
        for j in selected
            sj=sp[j]
            ji=findall(i->ind[i,sj]>0 && ci.b[i]==hc.b[sj],1:nw)
            @assert length(ji)==1 (H,j,sj,ji)
            @assert ind[only(ji),sj]==1
            orbit=pairs[only(ji)][1]; hits=findall(>(0),ind[:,j])
            @assert all(i->om[pairs[i][1],orbit],hits) (H,j,orbit,hits)
            push!(seeds,(mask,string(H),Kname,j,hn[j],sj,hn[sj],hc.a[j],hc.b[j],orbit,U.classes[orbit].name,hits))
        end
        checked+=1
        if checked%40==0
            println("E$n all-affine processed $checked projected subgroups, $(length(seeds)) source blocks");flush(stdout)
        end
    end
    open(joinpath(EXCEPTIONAL_OUTPUT,"E$(n)_allaffine_sources.tsv"),"w") do io
        println(io,"affine_subset_mask\tH\tK\tH_character_index\tH_character\tfamily_special_index\tfamily_special\ta\tb\torbit_index\torbit\thit_W_characters")
        for s in seeds
            println(io,join((s[1:11]...,join(s[12],',')),'\t'))
        end
    end
    println("E$n ALL-AFFINE completed $checked projected finite subgroups, $(length(seeds)) verified source blocks")
    (W=W,U=U,ci=ci,seeds=seeds,missing=Int[])
end

E7_allaffine=all_affine_sources(E7_coverage,7)
E7_allaffine_retention=richardson_retention(E7_allaffine,7;filetag="_allaffine")
E8_allaffine=all_affine_sources(E8_coverage,8)
E8_allaffine_retention=richardson_retention(E8_allaffine,8;filetag="_allaffine",hypothetical_adjoint=true)
