using Chevie,LinearAlgebra,SparseArrays,TOML
W=coxgroup(:E,6);ci=charinfo(W);ns=charnames(W);i=findfirst(==("phi10,9"),ns)
R=representation(W,i);@assert isrepresentation(W,R)
ct=CharTable(W)
for(k,g)in enumerate(classreps(W))
 m=one(R[1]);for s in word(W,g);m=m*R[s];end
 @assert tr(m)==ct.irr[i,k]
end
K=reflection_subgroup(W,[1,2,3,5,6]);im=induction_table(K,W).scalar[:,charinfo(K).positionDet]
println("LOW_DEGREES ",[(ns[j],ci.b[j],im[j]) for j in findall(>(0),im) if ci.b[j]<=9])
ms=[]
for r in R
 a,b,c=findnz(r);push!(ms,[[a[k],b[k],c[k]] for k=eachindex(c)])
end
base=joinpath(@__DIR__,"exceptional_source_tables")
open(joinpath(base,"E6_phi10_polynomial_probe_rep.toml"),"w")do io
 TOML.print(io,Dict("label"=>ns[i],"dimension"=>10,"sparse_generators"=>ms,
  "class_trace_check"=>true,"target_K_det_multiplicity"=>im[i]))
end
