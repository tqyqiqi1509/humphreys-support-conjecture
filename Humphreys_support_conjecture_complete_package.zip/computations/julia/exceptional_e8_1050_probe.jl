using Chevie,LinearAlgebra,SparseArrays
function main()
W=coxgroup(:E,8);ci=charinfo(W);ct=CharTable(W)
names=charnames(W);i=findfirst(==("phi1050,34"),names);@assert !isnothing(i)
r=ct.irr[i,:].*ct.irr[ci.positionDet,:];j=findfirst(k->ct.irr[k,:]==r,axes(ct.irr,1))
println("TARGET ",i," ",names[i]," POSITIVE ",j," ",names[j]);flush(stdout)
R=representation(W,j);println("REP ",typeof(R)," size ",size(R[1])," eltype ",eltype(R[1])," nnz ",[nnz(r) for r in R]);flush(stdout)
serialize=0
end
main()
