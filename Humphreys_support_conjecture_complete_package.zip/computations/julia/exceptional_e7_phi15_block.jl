using Chevie,Serialization,LinearAlgebra
using TOML
tomlify(x::NamedTuple)=Dict(string(k)=>tomlify(v) for (k,v) in pairs(x))
tomlify(x::AbstractVector)=tomlify.(x)
tomlify(x)=x
function main()
W=coxgroup(:E,7);ci=charinfo(W);ct=CharTable(W)
i=5;row=ct.irr[i,:].*ct.irr[ci.positionDet,:];j=findfirst(k->ct.irr[k,:]==row,axes(ct.irr,1))
println("TARGET",charnames(W)[i]," DETTWIST",j," ",charnames(W)[j]);flush(stdout)
R=representation(W,j);println(typeof(R)," ",size(R[1])," ",eltype(R[1]));flush(stdout)
println("VERIFIED",isrepresentation(W,R));flush(stdout)
for (k,g) in enumerate(classreps(W))
 m=one(R[1]);for s in word(W,g);m=m*R[s];end
 @assert tr(m)==ct.irr[j,k]
end
println("ALL_CLASS_TRACES_VERIFIED");flush(stdout)
d=deserialize("humphreys/compute/exceptional_source_tables/E7_A6_short_sources.jls")
# Equal-parameter finite symmetrizer = product over a reduced longest expression,
# using the canonical recursion (or its direct group sum). Here A6 order5040,
# direct sum of exact15x15 matrices is small and avoids projector normalization.
H=reflection_subgroup(W,d.J); e=zero(R[1]);
for h in elements(H)
 m=one(R[1]);for s in word(W,h);m=m*R[s];end;e+=m
end
println("PARABOLIC_TRIV_MULT",tr(e)//order(H));flush(stdout)
cells=Dict(parse(Int,split(r,'\t')[1])=>parse(Int,split(r,'\t')[9]) for r in readlines("humphreys/compute/exceptional_source_tables/E7_A6_short_cells.tsv")[2:end])
hit=[]
for idx in 1:length(d.xs)
 cells[idx]==25 || continue
 c=zero(R[1]);
 for (y,q) in d.canonical[idx]
  m=one(R[1]);for s in word(W,d.xs[y]);m=m*R[s];end
  c+=q(1).*m
 end
 z=c*e
 if !iszero(z)
  push!(hit,(idx,d.lens[idx],d.known[idx],d.witness[idx],sum(abs2,z),tr(z)))
  println("HIT",last(hit)," WORD",word(W,d.xs[idx]));flush(stdout)
  if d.known[idx]
   open("humphreys/compute/exceptional_source_tables/E7_phi15_source_matrix_$(idx).tsv","w") do io
    for row in eachrow(z);println(io,join(row,'\t'));end
   end
   if idx==259
    receipt=(ordinary_label=charnames(W)[i],positive_label=charnames(W)[j],
      index=idx,coset_word=word(W,d.xs[idx]),full_word=word(W,d.xs[idx]*longest(H)),
      certified=d.known[idx],witness=d.witness[idx],trace=tr(z),sum_squares=sum(abs2,z),
      generators=[collect.(eachrow(Matrix(r))) for r in R],
      parabolic_sum=collect.(eachrow(Matrix(e))),matrix=collect.(eachrow(Matrix(z))),
      terms=[(word=word(W,d.xs[y]),coefficient=q(1)) for(y,q)in d.canonical[idx]])
    open("humphreys/compute/exceptional_source_tables/E7_phi15_source259_receipt.toml","w") do io
      TOML.print(io,tomlify(receipt))
    end
   end
  end
 end
end
println("TOTAL_HITS",length(hit)," CERTIFIED",count(r->r[3],hit));flush(stdout)
end
main()
