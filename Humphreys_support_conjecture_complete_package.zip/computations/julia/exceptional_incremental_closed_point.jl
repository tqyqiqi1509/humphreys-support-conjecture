# Incremental exact semisimple-germ coverage. Only four new full-W blocks
# and one actual affine D8 block are added; old511 masks are not recomputed.
using Chevie,TOML
basepath=joinpath(@__DIR__,"exceptional_positive_source_coverage.jl")
include_string(Main,first(split(read(basepath,String),"E7_coverage=exceptional_sources(7)")),basepath)
include(joinpath(@__DIR__,"exceptional_semisimple_trace_coverage.jl"))
function read_tsv(path)
 isfile(path)||return nothing
 lines=readlines(path);keys=split(lines[1],'\t')
 Dict(parse(Int,r[1])=>Dict(String(k)=>String(v) for(k,v)in zip(keys,r)) for r in split.(lines[2:end],'\t'))
end
function incremental(yindex)
 n=8;Wsc=rootdatum(:E8);ys=quasi_isolated_reps(Wsc);@assert 1<=yindex<=length(ys)
 ctx=semisimple_trace_setup(Wsc,ys[yindex]);W,M=ctx.W,ctx.M
 U=UnipotentClasses(W);UM=UnipotentClasses(M);pg=U.springerseries[1][:locsys];pm=UM.springerseries[1][:locsys]
 og=incidence(U.orderclasses);ci=charinfo(W);cm=charinfo(M);names=charnames(W);mn=charnames(M);nm=length(cm.b)
 embedded=[findfirst(c->c.dynkin==induced_linear_form(Wsc,M,u.dynkin),U.classes) for u in UM.classes]
 @assert all(!isnothing,embedded)
 baseline=read_tsv(joinpath(EXCEPTIONAL_OUTPUT,"E8_semisimple_$(yindex)_upgraded_coverage.tsv"))
 if isnothing(baseline)&&yindex==1
  baseline=read_tsv(joinpath(EXCEPTIONAL_OUTPUT,"E8_upgraded_retention_coverage.tsv"))
 end
 allowed=[trues(length(U.classes)) for _=1:nm]
 for inds in parabolic_reps(M)
  L=reflection_subgroup(M,inds);rational_weyl_table!(L);cl=charinfo(L)
  im=induction_table(L,M).scalar[:,cl.positionDet];ig=induction_table(L,W).scalar[:,cl.positionDet]
  jj=findall(i->ig[i]>0 && ci.b[i]==cl.b[cl.positionDet],eachindex(ig));@assert length(jj)==1
  orbit=pg[only(jj)][1];hit=findall(>(0),im)
  @assert all(i->og[embedded[pm[i][1]],orbit],hit)
  for i in hit;allowed[i].&=og[:,orbit];end
 end
 println("INCREMENTAL E8 y",yindex," M=",isomorphism_type(M)," chars=",nm," orbit=",length(ctx.reps)," baseline=",!isnothing(baseline));flush(stdout)
 sources=[];family=family_special_map(W)
 # Translation cocycle is trivial for the finite full-W source at the
 # ordinary vertex. Thus the restriction matrix is ordinary Ind_M^W.
 indM=induction_table(M,W).scalar
 for label in ["phi1050,34","phi560,47","phi210,52","phi50,56"]
  j=findfirst(==(label),names);@assert !isnothing(j);sj=family[j];bound=pg[sj][1]
  @assert ci.a[j]==ci.b[sj]
  hit=findall(>(0),indM[j,:]);@assert all(i->og[embedded[pm[i][1]],bound],hit) (yindex,label,bound,hit)
  push!(sources,("fullW_"*label,bound,hit))
  println(" SOURCE ",label," family=",names[sj]," bound=",U.classes[bound].name," hits=",length(hit));flush(stdout)
 end
 # D8 pure positive(5,3) corresponds to ordinary det-twist .22211.
 mask=510;simple=vcat(collect(1:n),[highest_short_root(W)])
 H=reflection_subgroup(W,[simple[j] for j=1:9 if !iszero(mask&(1<<(j-1)))])
 rational_weyl_table!(H);hc=charinfo(H);hn=charnames(H);j=28
 @assert hn[j]==".22211" (hn[j],hc.charparams[j])
 @assert hc.a[j]==24 && hc.b[j]==26
 hs=family_special_map(H)[j];@assert hc.a[hs]==24 && hc.b[hs]==24
 ih=induction_table(H,W).scalar;jj=findall(k->ih[k,hs]>0 && ci.b[k]==24,eachindex(ci.b));@assert length(jj)==1
 bound=pg[only(jj)][1]
 famreceipt=Dict("affine_mask"=>mask,"finite_index"=>j,"finite_character"=>hn[j],
   "finite_a"=>hc.a[j],"finite_b"=>hc.b[j],"finite_special_index"=>hs,
   "finite_special_character"=>hn[hs],"ambient_j_induction"=>names[only(jj)],
   "ambient_bound"=>U.classes[bound].name,
   "cell_identification"=>"Exact finite D family identified by the signed doubleword RSK symbol (Bai--Xiao--Xie 2005.11536v3 Section 3), independently checked by root and intrinsic; the nonzero pure-block action is a separate full-block witness.")
 open(joinpath(EXCEPTIONAL_OUTPUT,"E8_D8_actual28_family_audit.toml"),"w")do io;TOML.print(io,famreceipt);end
 xi=affine_fixed_weight(Wsc,mask,n)
 mult=affine_restriction_multiplicities(ctx,H,xi);hit=findall(>(0),mult[j,:])
 @assert all(i->og[embedded[pm[i][1]],bound],hit) (yindex,mask,j,bound,hit)
 push!(sources,("affine_D8_mask510_char28",bound,hit))
 println(" SOURCE D8char28 family=",hn[hs]," bound=",U.classes[bound].name," hits=",length(hit));flush(stdout)
 neww=fill("",nm);source_rows=[]
 for (label,bound,hit) in sources
  for i in hit
   target=embedded[pm[i][1]];inter=allowed[i].&og[:,bound]
   valid=all(k->!inter[k] || og[k,target],eachindex(inter))
   push!(source_rows,(label,U.classes[bound].name,i,mn[i],U.classes[target].name,valid))
   valid && isempty(neww[i]) && (neww[i]=label)
  end
 end
 out=joinpath(EXCEPTIONAL_OUTPUT,"E8_semisimple_$(yindex)_incremental_coverage.tsv")
 rows=[]
 open(out,"w")do io
  println(io,"index\tcharacter\tlocal_orbit\tambient_orbit\tb\ttrivial_local_system\tcovered\twitness\tbaseline_covered\tnew_covered\tbaseline_available")
  for i=1:nm
   o,ls=pm[i];tr=ls==charinfo(UM.classes[o].Au).positionId
   old=!isnothing(baseline) && baseline[i]["covered"]=="true"
   !isnothing(baseline) && @assert baseline[i]["character"]==mn[i]
   oldw=old ? baseline[i]["witness"] : "";fresh=!isempty(neww[i]);yes=old||fresh;w=fresh ? neww[i] : oldw
   row=(i,mn[i],UM.classes[o].name,U.classes[embedded[o]].name,cm.b[i],tr,yes,w,old,fresh,!isnothing(baseline))
   push!(rows,row);println(io,join(row,'\t'))
  end
 end
 open(joinpath(EXCEPTIONAL_OUTPUT,"E8_semisimple_$(yindex)_incremental_witnesses.tsv"),"w")do io
  println(io,"source\tbound\tlocal_index\tlocal_character\tambient_target\tcut_succeeds")
  for r in source_rows;println(io,join(r,'\t'));end
 end
 println("INCREMENTAL_DONE y",yindex," all=",count(r->r[7],rows),"/",nm," trivial=",count(r->r[6]&&r[7],rows),"/",count(r->r[6],rows));flush(stdout)
 for r in rows;r[6]&&!r[7]&&println(" MISSING ",r);end
 flush(stdout)
end
incremental(parse(Int,ARGS[1]))
