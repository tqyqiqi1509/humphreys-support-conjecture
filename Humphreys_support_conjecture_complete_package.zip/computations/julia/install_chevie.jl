using Pkg
Pkg.add(PackageSpec(name="Chevie",version="0.1.15"))
Pkg.status()
using Chevie
W=coxgroup(:E,8)
println("CHEVIE_E8_ORDER=",order(W))
println("CHEVIE_E8_CHARACTERS=",length(charinfo(W).charparams))
