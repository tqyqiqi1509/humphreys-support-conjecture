using Chevie,Serialization,TOML
p=joinpath(@__DIR__,"exceptional_source_tables","E6_A5_contact_short_sources.jls")
d=deserialize(p);W=coxgroup(:E,6)
o=[]
for i in [70,71,72]
 c=d.canonical[i];terms=[]
 for (j,q) in sort(collect(c))
  push!(terms,Dict("index"=>j,"length"=>d.lens[j],"word"=>word(W,d.xs[j]),"kl_laurent"=>string(q),"euler"=>q(1)))
 end
 push!(o,Dict("index"=>i,"length"=>d.lens[i],"word"=>word(W,d.xs[i]),"terms"=>terms))
 println("SOURCE ",i," length ",d.lens[i]," word ",word(W,d.xs[i])," base ",c[1])
end
open(replace(p,".jls"=>"_summary.toml"),"w")do io;TOML.print(io,Dict("sources"=>o));end
