using Chevie,TOML
driver=joinpath(@__DIR__,"exceptional_maximal_final_coverage.jl")
include_string(Main,first(split(read(driver,String),"@assert length(ARGS)in(1,2)")),driver)
function derivative_cut_test()
 Wsc=rootdatum(:E8);W=coxgroup(:E,8);ys=quasi_isolated_reps(Wsc)
 M=centralizer(Wsc,ys[4]).group;rational_weyl_table!(M)
 U=UnipotentClasses(W);UM=UnipotentClasses(M);ci=charinfo(W)
 pg=U.springerseries[1][:locsys];pm=UM.springerseries[1][:locsys]
 og=incidence(U.orderclasses);names=charnames(M)
 emb=[findfirst(c->c.dynkin==induced_linear_form(Wsc,M,u.dynkin),U.classes) for u in UM.classes]
 Eidx=9;Fidx=51;@assert names[Eidx]=="phi10,9,3";@assert names[Fidx]=="phi60,8,3"
 target=emb[pm[Eidx][1]];bound=emb[pm[Fidx][1]];allowed=copy(og[:,bound]);cutrows=[]
 println("DERIVATIVE_CUT_START E=",names[Eidx]," F=",names[Fidx]," bound=",U.classes[bound].name," target=",U.classes[target].name);flush(stdout)
 for inds in parabolic_reps(M)
  L=reflection_subgroup(M,inds);rational_weyl_table!(L);cl=charinfo(L)
  im=induction_table(L,M).scalar[:,cl.positionDet];im[Eidx]>0||continue
  ig=induction_table(L,W).scalar[:,cl.positionDet]
  jj=findall(i->ig[i]>0&&ci.b[i]==cl.b[cl.positionDet],eachindex(ig));@assert length(jj)==1
  o=pg[only(jj)][1];@assert og[target,o]
  allowed .&=og[:,o]
  push!(cutrows,Dict("L"=>string(L),"simple_indices"=>inds,"bound_index"=>o,"bound"=>U.classes[o].name,"E_multiplicity"=>im[Eidx]))
 end
 ok=all(k->!allowed[k]||og[k,target],eachindex(allowed))
 maximal=[k for k in eachindex(allowed) if allowed[k]&&!any(j->j!=k&&allowed[j]&&og[k,j],eachindex(allowed))]
 receipt=Dict("target_index"=>Eidx,"target_character"=>names[Eidx],"source_index"=>Fidx,"source_character"=>names[Fidx],"source_bound"=>U.classes[bound].name,"target_bound"=>U.classes[target].name,"cuts"=>cutrows,"intersection_is_target"=>ok,"intersection_maximal_orbits"=>[U.classes[k].name for k in maximal],"surviving_orbits"=>[U.classes[k].name for k in eachindex(allowed) if allowed[k]])
 open(joinpath(EXCEPTIONAL_OUTPUT,"E8_y4_E6_derivative_retaining_cut.toml"),"w")do io;TOML.print(io,receipt);end
 println("DERIVATIVE_CUT_RESULT ",ok," maximal=",receipt["intersection_maximal_orbits"]," cuts=",length(cutrows));flush(stdout)
end
derivative_cut_test()
GC.gc()
final_maximal_vertex(9;adaptive=true)
