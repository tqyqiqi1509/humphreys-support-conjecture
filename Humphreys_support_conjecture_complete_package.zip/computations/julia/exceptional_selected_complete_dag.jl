# Constructive p-independence propagation via Jensen's parabolic-coset
# coefficient theorem (1901.02323, Corollary 3.10) and KL positivity.
# All parabolics used have rank<=6, whose complete p-canonical basis is
# published to equal KL for p>7. No assertion about full E7/E8 is assumed.
using Chevie, Serialization, TOML
const vv=Pol()
const VP=typeof(vv)
const VectorP=Dict{Int,VP}
function add!(a,i,q)
 z=get(a,i,zero(vv))+q
 if iszero(z);delete!(a,i);else;a[i]=z;end
end
function certify_chain(n,tag,targets)
 path=joinpath(@__DIR__,"exceptional_source_tables","E$(n)_$(tag)_short_sources.jls")
 d=deserialize(path);W=coxgroup(:E,n);wJ=longest(reflection_subgroup(W,d.J))
 known=copy(d.known);witness=copy(d.witness);corr=copy(d.corrections)
 edges=[(1,3),(3,4),(2,4),(4,5),(5,6),(6,7),(7,8)]
 function small_components(I)
  todo=Set(I)
  while !isempty(todo)
   queue=[pop!(todo)];at=1
   while at<=length(queue)
    a=queue[at]
    for (j,k) in edges
     b=j==a ? k : k==a ? j : 0
     if b in todo;delete!(todo,b);push!(queue,b);end
    end
    at+=1
   end
   length(queue)>6 && return false
  end
  true
 end
 certrows=Tuple[]
 function product(s,z)
  a=VectorP()
  for(i,c)in d.canonical[z]
   j=d.acts[s,i];@assert j>0
   if j==i;add!(a,i,(vv+vv^-1)*c)
   else;add!(a,j,c);add!(a,i,(d.lens[j]>d.lens[i] ? vv : vv^-1)*c)
   end
  end
  a
 end
 function lower(s,z,i)
  begin
   a=product(s,z)
   for(k,q)in d.canonical[i];add!(a,k,-q);end
   c=Pair{Int,Int}[]
   for y=i-1:-1:1
    q=get(a,y,zero(vv));iszero(q)&&continue
    @assert degree(q)==0 && valuation(q)==0 && q[0]>0
    push!(c,y=>q[0])
    for(k,r)in d.canonical[y];add!(a,k,-q*r);end
   end
   @assert isempty(a)
   c
  end
 end
 # Known individual E7 canonical elements, embedded in nodes1..7.
 knownE7=Dict{typeof(one(W)),String}()
 if n==8
  for tg in ["A6","D5"]
   f=joinpath(@__DIR__,"exceptional_source_tables","E7_$(tg)_short_sources.tsv")
   for line in readlines(f)[2:end]
    r=split(line,'\t');r[4]=="true"||continue
    g=prod(W.(parse.(Int,split(r[7],','))));ref="E7_$(tg)_source$(r[1])"
    knownE7[g]=ref;knownE7[inv(g)]=ref*"_inverse"
   end
  end
 end
 function known_upper(g,I)
  small_components(sort(unique(word(W,g)))) && return "finite_components_le6"
  if I==collect(1:7)
   haskey(knownE7,g) && return knownE7[g]
   all(s->isrightdescent(W,g,s),1:6) && return "E7_E6_minuscule"
  elseif I==collect(2:8)
   for omit in [2,3,8]
    all(s->isrightdescent(W,g,s),setdiff(I,[omit])) && return "D7_minuscule_omit$(omit)"
   end
  elseif I==[1,3,4,5,6,7,8]
   for omit in I
    all(s->isrightdescent(W,g,s),setdiff(I,[omit])) && return "A7_minuscule_omit$(omit)"
   end
  end
  nothing
 end
 function right_factor(g,I)
  u=g;b=one(W)
  while true
   ss=findfirst(s->isrightdescent(W,u,s),I);isnothing(ss)&&return b
   s=I[ss];u=u*W(s);b=W(s)*b
  end
 end
 function cosetproof(i,y)
  wi=d.xs[i]*wJ;wy=d.xs[y]*wJ
  for (side,g) in [("left",wi*inv(wy)),("right",inv(wy)*wi)]
   I=sort(unique(word(W,g)))
   small_components(I) && return (side,I,"finite_components_le6")
   if length(I)==7 && n==8
    upper=right_factor(side=="left" ? inv(wi) : wi,I)
    ref=known_upper(upper,I)
    !isnothing(ref) && return (side,I,ref*":upper="*join(word(W,upper),","))
   end
  end
  nothing
 end

 nodes=Dict{Int,Any}()
 function source_details(ref,b)
  m=match(r"E7_(A6|D5)_source([0-9]+)",ref)
  isnothing(m) && return (kind=ref,)
  tg=m.captures[1];idx=parse(Int,m.captures[2]);rr=split(readlines(joinpath(@__DIR__,"exceptional_source_tables","E7_$(tg)_short_sources.tsv"))[idx+1],'\t')
  sx=parse.(Int,split(rr[6],','));sw=parse.(Int,split(rr[7],','));Jsrc=tg=="A6" ? [1,3,4,5,6,7] : [2,3,4,5,6]
  sb=prod(W.(sw));xx=prod(W.(sx))
  @assert sb==xx*longest(reflection_subgroup(W,Jsrc))
  @assert b==sb || b==inv(sb)
  (kind="certified_E7_source",source_tag=tg,source_index=idx,source_coset_word=sx,
    source_J=Jsrc,source_full_word=sw,inverted=(b!=sb))
 end
 function build_node(i)
  haskey(nodes,i)&&return
  x=d.xs[i];wi=x*wJ;I=sort(unique(word(W,x)));K=intersect(I,d.J)
  if small_components(I)
   nodes[i]=(index=i,method="partial_Levi_components_le6",parabolic_nodes=I,
      intersection_J=K,coset_word=word(W,x),full_word=word(W,wi))
   return
  end
  if n==8 && length(I)==7
   b=x*longest(reflection_subgroup(W,K));ref=known_upper(b,I)
   if !isnothing(ref)
    @assert all(isrightdescent(W,b,t) for t in K)
    nodes[i]=(index=i,method="partial_Levi_known_upper",parabolic_nodes=I,intersection_J=K,
      coset_word=word(W,x),full_word=word(W,wi),upper_word=word(W,b),
      upper_right_descents=[t for t in I if isrightdescent(W,b,t)],upper_certificate=ref,
      upper_source=source_details(ref,b))
    return
   end
  end
  ma=match(r"_(\d+)_from_(\d+)",d.witness[i]);@assert !isnothing(ma) (i,d.witness[i])
  s=parse(Int,ma.captures[1]);z=parse(Int,ma.captures[2]);@assert d.acts[s,i]==z
  @assert W(s)*d.xs[z]==x;build_node(z)
  cc=lower(s,z,i);corrections=[]
  for(y,m)in cc
   pr=cosetproof(i,y);@assert !isnothing(pr) (i,y)
   side,I,ref=pr;wy=d.xs[y]*wJ
   relative=side=="left" ? wi*inv(wy) : inv(wy)*wi
   if small_components(I)
    push!(corrections,(lower=y,multiplicity=m,coset_side=side,parabolic_nodes=I,
       relative_word=word(W,relative),lower_full_word=word(W,wy),upper_certificate="finite_components_le6"))
   else
    inverse=side=="left";ww=inverse ? inv(wi) : wi;yy=inverse ? inv(wy) : wy
    b=right_factor(ww,I);u=ww*inv(b);a=inv(u)*yy
    @assert all(!isrightdescent(W,u,t) for t in I)
    @assert all(t in I for t in word(W,a))
    @assert length(W,ww)==length(W,u)+length(W,b)
    @assert length(W,yy)==length(W,u)+length(W,a)
    ref=known_upper(b,I);@assert !isnothing(ref)
    push!(corrections,(lower=y,multiplicity=m,coset_side=side,parabolic_nodes=I,
      relative_word=word(W,relative),lower_full_word=word(W,wy),upper_certificate=ref,
      upper_word=word(W,b),upper_right_descents=[t for t in I if isrightdescent(W,b,t)],
      jensen_applied_after_inversion=inverse,common_minimal_right_coset_word=word(W,u),
      lower_parabolic_word=word(W,a),upper_source=source_details(ref,b)))
   end
  end
  nodes[i]=(index=i,method="Jensen_coset",simple=s,predecessor=z,
     coset_word=word(W,x),full_word=word(W,wi),corrections=corrections)
 end
 for target in targets
  build_node(target);dag=Int[];i=target
  while true
   push!(dag,i);pr=nodes[i];pr.method!="Jensen_coset"&&break;i=pr.predecessor
  end
  reverse!(dag);used=Set(dag)
  for i in dag
   pr=nodes[i];pr.method!="Jensen_coset"&&continue
   for c in pr.corrections;push!(used,c.lower);end
  end
  vectors=[]
  for i in sort(collect(used))
   push!(vectors,(index=i,terms=[(index=y,coset_word=word(W,d.xs[y]),
    polynomial=[[e,q[e]] for e in valuation(q):degree(q) if q[e]!=0]) for(y,q)in sort(collect(d.canonical[i]))]))
  end
  receipt=(rank=n,parabolic_J=d.J,p_range="prime p>7",target=target,
    rule="exactly rechecked Jensen chain; rank<=6 finite inputs and separately certified rank7 upper elements",
    dag=dag,nodes=[nodes[i] for i in dag],canonical_vectors=vectors)
  out=joinpath(@__DIR__,"exceptional_source_tables","E$(n)_$(tag)_source$(target)_complete_dag.toml")
  open(out,"w")do io;TOML.print(io,tomlify(receipt));end
  println("COMPLETE_CHAIN ",target," ",dag," VECTORS ",length(vectors));flush(stdout)
 end
end
tomlify(x::NamedTuple)=Dict(string(k)=>tomlify(v) for(k,v)in pairs(x))
tomlify(x::AbstractVector)=tomlify.(x)
tomlify(x)=x
certify_chain(parse(Int,ARGS[1]),ARGS[2],parse.(Int,ARGS[3:end]))
