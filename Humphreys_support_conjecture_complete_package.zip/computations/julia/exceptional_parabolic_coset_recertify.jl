# Constructive p-independence propagation via Jensen's parabolic-coset
# coefficient theorem (1901.02323, Corollary 3.10) and KL positivity.
# All parabolics used have rank<=6, whose complete p-canonical basis is
# published to equal KL for p>7. No assertion about full E7/E8 is assumed.
using Chevie, Serialization
const vv=Pol()
const VP=typeof(vv)
const VectorP=Dict{Int,VP}
function add!(a,i,q)
 z=get(a,i,zero(vv))+q
 if iszero(z);delete!(a,i);else;a[i]=z;end
end
function recertify(n,tag)
 path=joinpath(@__DIR__,"exceptional_source_tables","E$(n)_$(tag)_short_sources.jls")
 d=deserialize(path);W=coxgroup(:E,n);wJ=longest(reflection_subgroup(W,d.J))
 known=copy(d.known);witness=copy(d.witness);corr=copy(d.corrections)
 certrows=Tuple[]
 function product(s,z)
  a=VectorP()
  for(i,c)in d.canonical[z]
   j=d.acts[s,i];@assert j>0
   if j==i;add!(a,i,(vv+vv^-1)*c)
   else;add!(a,j,c);add!(a,i,(d.lens[j]>d.lens[i] ? vv : vv^-1)*c)
   end
  end
  a
 end
 function lower(s,z,i)
  get!(corr,(s,z)) do
   a=product(s,z)
   for(k,q)in d.canonical[i];add!(a,k,-q);end
   c=Pair{Int,Int}[]
   for y=i-1:-1:1
    q=get(a,y,zero(vv));iszero(q)&&continue
    @assert degree(q)==0 && valuation(q)==0 && q[0]>0
    push!(c,y=>q[0])
    for(k,r)in d.canonical[y];add!(a,k,-q*r);end
   end
   @assert isempty(a)
   c
  end
 end
 function cosetproof(i,y)
  L=sort(unique(word(W,d.xs[i]*inv(d.xs[y]))))
  length(L)<=6 && return ("left",L)
  R=sort(unique(word(W,wJ*inv(d.xs[y])*d.xs[i]*wJ)))
  length(R)<=6 && return ("right",R)
  nothing
 end
 for i=2:length(d.xs)
  known[i] && continue
  for s=1:n
   z=d.acts[s,i]
   (0<z<i && known[z])||continue
   cc=lower(s,z,i);pr=[cosetproof(i,y) for(y,m)in cc]
   all(!isnothing,pr)||continue
   known[i]=true;witness[i]="Jensen_coset_$(s)_from_$(z)_pgt7"
   for((y,m),proof)in zip(cc,pr)
    push!(certrows,(i,s,z,y,m,proof[1],join(proof[2],",")))
   end
   isempty(cc)&&push!(certrows,(i,s,z,0,0,"empty",""))
   break
  end
 end
 open(replace(path,"_short_sources.jls"=>"_coset_certificates.tsv"),"w") do io
  println(io,"target\tsimple\tpredecessor\tlower\tmultiplicity\tcoset_side\tparabolic_nodes")
  for r in certrows;println(io,join(r,'\t'));end
 end
 source=replace(path,".jls"=>".tsv")
 lines=readlines(source)
 open(source,"w") do io
  println(io,lines[1])
  for line in lines[2:end]
   r=split(line,'\t');i=parse(Int,r[1]);r[4]=string(known[i]);r[5]=witness[i]
   println(io,join(r,'\t'))
  end
 end
 serialize(path,merge(d,(known=known,witness=witness,corrections=corr)))
 println("E$n $tag before",count(d.known)," after",count(known)," total",length(known));flush(stdout)
end
n=parse(Int,ARGS[1])
for tag in ARGS[2:end];recertify(n,tag);end
