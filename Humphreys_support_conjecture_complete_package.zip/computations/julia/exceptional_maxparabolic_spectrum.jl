using Chevie
function rational_weyl_table!(H)
    # CHEVIE0.1.15's product-table builder asks for prime power maps beyond
    # the stored E7 maps (e.g.11). Every entry of a Weyl character table is
    # rational: if gcd(m,|H|)=1, Galois invariance gives g^m conjugate to g.
    # Thus the missing coprime maps are exactly the identity, not guesses.
    tables=CharTable[CharTable(t) for t in refltype(H)]
    for (t,ct) in zip(refltype(H),tables)
        if haskey(ct,:powermaps) && haskey(ct,:orders)
            @assert all(x->x==Int(x),ct.irr)
            # ClassInfo maintains a separate optional map cache; complete
            # its shared vector too, so conjugacy-class fusion can use it.
            cin=classinfo(t)
            pmlists=haskey(cin,:powermaps) ? [ct.powermaps,cin.powermaps] : [ct.powermaps]
            for pm in pmlists
                needed=maximum(ct.orders)
                append!(pm,fill(nothing,max(0,needed-length(pm))))
                for m in eachindex(pm)
                    if isnothing(pm[m]) && gcd(m,ct.order)==1
                        pm[m]=collect(eachindex(ct.orders))
                    end
                end
            end
        end
    end
    H.chartable=prod(tables)
    H.chartable
end


function main()
 W=coxgroup(:E,8);ci=charinfo(W);names=charnames(W)
 wanted=["phi210,52","phi50,56","phi1050,34","phi1575,34","phi1400,32","phi8,91","phi35,74"]
 ids=[findfirst(==(x),names) for x in wanted];@assert all(!isnothing,ids)
 out="humphreys/compute/exceptional_source_tables/E8_maxparabolic_target_multiplicities.tsv"
 open(out,"w")do io
  println(io,join(vcat(["omitted_node","parabolic","index"],wanted), '\t'))
  for j=1:8
   J=setdiff(1:8,[j]);H=reflection_subgroup(W,J);rational_weyl_table!(H)
   mult=induction_table(H,W).scalar[:,charinfo(H).positionDet]
   row=[j,string(H),div(order(W),order(H)),mult[ids]...]
   println(io,join(row,'\t'));flush(io);println(row);flush(stdout)
  end
 end
end
main()
