using Chevie, Serialization
function main()
 base=joinpath(@__DIR__,"exceptional_source_tables")
 d=deserialize(joinpath(base,"E8_A7deep_short_sources.jls"))
 edges=Set{Tuple{Int,Int}}()
 for i=1:length(d.xs)
  ascend=[s for s=1:8 if d.acts[s,i]==0||d.acts[s,i]>i]
  for s in ascend
   j=d.acts[s,i];j>0&&push!(edges,(i,j))
  end
  for(y,q)in d.canonical[i]
   y<i&&q[1]>0||continue
   any(s->0<d.acts[s,y]<=y,ascend)&&push!(edges,(i,y))
  end
 end
 open(joinpath(base,"E8_A7deep_leftcell_edges.tsv"),"w")do io
  println(io,"from\tto")
  for(i,j)in sort(collect(edges));println(io,i,'\t',j);end
 end
 println("EXPORTED ",length(edges)," true left-preorder edges among ",length(d.xs)," nodes")
end
main()
