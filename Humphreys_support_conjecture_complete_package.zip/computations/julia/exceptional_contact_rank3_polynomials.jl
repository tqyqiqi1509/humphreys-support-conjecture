using Chevie, Serialization, TOML
d=deserialize(joinpath(@__DIR__,"exceptional_source_tables","E8_A7_short_sources.jls"))
W=coxgroup(:E,8);i2=findfirst(==(W(2)),d.xs);@assert !isnothing(i2)
out=[]
for(i,j)in [(509,i2),(1221,277),(2794,277),(277,i2)]
 h=get(d.canonical[i],j,Pol(0));delta=d.lens[i]-d.lens[j]
 powers=[(delta-e)÷2 for e=valuation(h):degree(h) if h[e]!=0]
 coeff=[Int(h[e]) for e=valuation(h):degree(h) if h[e]!=0]
 @assert all(e->h[e]==0||iseven(delta-e),valuation(h):degree(h))
 row=Dict("upper"=>i,"lower"=>j,"delta"=>delta,"h"=>string(h),"q_powers"=>powers,"q_coefficients"=>coeff,"Euler"=>Int(h(1)))
 push!(out,row);println(row)
end
open(joinpath(@__DIR__,"exceptional_source_tables","E8_contact_rank3_polynomials.toml"),"w")do io;TOML.print(io,Dict("rows"=>out));end
