using Chevie,TOML
function main()
 W=coxgroup(:E,8);ct=CharTable(W);names=charnames(W);j=findfirst(==("phi175,12"),names)
 data=Dict("label"=>names[j],"dimension"=>175,
  "classes"=>[Dict("word"=>word(W,g),"trace"=>Int(ct.irr[j,k])) for(k,g)in enumerate(classreps(W))])
 open("humphreys/compute/exceptional_source_tables/E8_phi175_class_checks.toml","w")do io;TOML.print(io,data);end
 println("CLASS_WORDS_EXPORTED ",length(data["classes"]))
end
main()
