# Exact canonical-basis / integral-recursion search in finite spherical modules.
# A canonical vector mbar_x represents C'_(x*w_J), not an arbitrary finite
# character idempotent. The ERT weak-cover criterion certifies p-independence
# for every p>3 (together with the indicated genuine minuscule seed).
using Chevie
using Serialization

const v=Pol()
const PV=typeof(v)
const VV=Dict{Int,PV}

function addterm!(a::VV,i,p)
    z=get(a,i,zero(v))+p
    if iszero(z); delete!(a,i); else; a[i]=z; end
    a
end

function search_short(J,depth;tag,rank=8)
    W=coxgroup(:E,rank); sw=[W(i) for i=1:rank]
    H=reflection_subgroup(W,J); wJ=longest(H)
    xs=[one(W)]; lens=[0]; ids=Dict(one(W)=>1)
    # Minimal right W_J cosets, with left simple-reflection action.
    at=1
    while at<=length(xs)
        x=xs[at]; d=lens[at]
        if d<depth
            for s=1:rank
                z=sw[s]*x
                any(j->isrightdescent(W,z,j),J) && continue
                if !haskey(ids,z)
                    push!(xs,z);push!(lens,length(W,z));ids[z]=length(xs)
                end
            end
        end
        at+=1
    end
    orderidx=sortperm(lens)
    xs=xs[orderidx];lens=lens[orderidx];ids=Dict(x=>i for(i,x)in enumerate(xs))
    n=length(xs); acts=zeros(Int,rank,n)
    for i=1:n,s=1:rank
        z=sw[s]*xs[i]
        acts[s,i]=any(j->isrightdescent(W,z,j),J) ? i : get(ids,z,0)
    end
    function product(s,vec)
        out=VV()
        for (i,c) in vec
            j=acts[s,i]
            j==0 && error("truncated action used above depth")
            if j==i
                addterm!(out,i,(v+v^-1)*c)
            else
                addterm!(out,j,c)
                addterm!(out,i,(lens[j]>lens[i] ? v : v^-1)*c)
            end
        end
        out
    end
    canonical=Vector{VV}(undef,n);canonical[1]=VV(1=>one(v))
    known=falses(n);known[1]=true
    witness=fill("",n);witness[1]="parabolic_longest"
    allcorr=Dict{Tuple{Int,Int},Vector{Pair{Int,Int}}}()
    for i=2:n
        s=first(s for s=1:rank if 0<acts[s,i]<i)
        z=acts[s,i];a=product(s,canonical[z]);corr=Pair{Int,Int}[]
        @assert get(a,i,zero(v))==one(v)
        for y=i-1:-1:1
            c=get(a,y,zero(v));iszero(c)&&continue
            b=Pol(c[0])
            for e=valuation(c):-1
                b+=c[e]*(v^e+v^-e)
            end
            if !iszero(b)
                @assert degree(b)==0 && b[0]>0 (tag,i,y,b)
                push!(corr,y=>b[0])
                for(k,q)in canonical[y];addterm!(a,k,-b*q);end
            end
        end
        @assert all(y==i || valuation(q)>0 for(y,q)in a)
        canonical[i]=a;allcorr[(s,z)]=corr
        if i%100==0;println("PROGRESS ",i," / ",n," length ",lens[i]," terms ",length(a));flush(stdout);end
        fullword=word(W,xs[i]*wJ)
        # Levi-supported partial flag inflation: X_x in G/P_J is the
        # same Schubert variety for the Levi on supp(x), with parabolic
        # J intersection supp(x). Published complete rank<=6 calculations
        # give p-canonical=KL for every p>7. This branch therefore changes
        # the certification threshold to p>7, still below p>h(E7).
        if length(unique(word(W,xs[i])))<=6
            known[i]=true;witness[i]="Levi_partial_inflation_rank_le6_pgt7"
        end
        # D7 / D6 is minuscule, hence its complete spherical basis is
        # p-independent for odd p (Baine theorem). No full D7 basis claim.
        if tag=="D6" && !(1 in fullword)
            known[i]=true;witness[i]="D7_D6_minuscule"
        end
        if rank==7 && tag=="D5" && !(7 in fullword)
            known[i]=true;witness[i]="E6_D5_minuscule"
        end
        if rank==7 && tag=="D5" && !(1 in fullword)
            known[i]=true;witness[i]="D6_D5_minuscule"
        end
        for ss=1:rank
            zz=acts[ss,i]
            (0<zz<i && known[zz])||continue
            aa=product(ss,canonical[zz]);cc=Pair{Int,Int}[]
            for(k,q)in canonical[i];addterm!(aa,k,-q);end
            for y=i-1:-1:1
                c=get(aa,y,zero(v));iszero(c)&&continue
                @assert degree(c)==0 && valuation(c)==0 && c[0]>0 (tag,i,ss,y,c)
                push!(cc,y=>c[0])
                for(k,q)in canonical[y];addterm!(aa,k,-c*q);end
            end
            @assert isempty(aa)
            allcorr[(ss,zz)]=cc
            if all(known[y] && lens[zz]-lens[y]==1 &&
                   any(t->acts[t,zz]==y,1:rank) for(y,m)in cc)
                known[i]=true;witness[i]="ERT_left_$(ss)_from_$(zz)"
                break
            end
        end
    end
    out=joinpath(@__DIR__,"exceptional_source_tables","E$(rank)_$(tag)_short_sources.tsv")
    open(out,"w")do io
        println(io,"index\tcoset_length\tfull_length\tcertified\twitness\tcoset_word\tfull_word\tstandard_terms")
        for i=1:n
            w=xs[i]*wJ
            println(io,join((i,lens[i],length(W,w),known[i],witness[i],
              join(word(W,xs[i]),","),join(word(W,w),","),length(canonical[i])),"\t"))
        end
    end
    serialize(replace(out,".tsv"=>".jls"),(J=J,rank=rank,depth=depth,xs=xs,lens=lens,
       acts=acts,canonical=canonical,known=known,witness=witness,corrections=allcorr))
    println(tag," depth=",depth," cosets=",n," certified=",count(known),
      " lengths=",[(d,count(==(d),lens),count(i->lens[i]==d&&known[i],1:n)) for d=0:depth]);flush(stdout)
end


search_short(collect(2:8),78;tag="D7",rank=8)
