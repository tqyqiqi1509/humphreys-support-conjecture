using Chevie, TOML
W=coxgroup(:E,8);H=reflection_subgroup(W,[2,3,4,5,6,7])
ci=charinfo(W);hc=charinfo(H);names=charnames(W)
m=induction_table(H,W).scalar[:,hc.positionDet]
out=[]
for i in findall(>(0),m)
 ci.b[i]>32&&continue
 f=fakedegree(W,ci.charparams[i])
 row=Dict("index"=>i,"label"=>names[i],"a"=>ci.a[i],"b"=>ci.b[i],
  "det_multiplicity"=>m[i],"fake_coeff32"=>Int(f[32]),"fake_degree"=>string(f))
 push!(out,row);println(row)
end
orth=[findfirst(==([2,2,3,4,3,2,1,0]),roots(W)),findfirst(==([2,3,4,6,5,4,3,2]),roots(W))]
HH=reflection_subgroup(W,vcat([2,3,4,5,6,7],Int.(orth)))
mm=induction_table(HH,W).scalar[:,charinfo(HH).positionDet]
println("D6A1A1 ",isomorphism_type(HH)," minimal ",[(names[i],ci.b[i],mm[i]) for i in findall(>(0),mm) if ci.b[i]<=32])
base=joinpath(@__DIR__,"exceptional_source_tables")
open(joinpath(base,"E8_D6_degree32_det_probe.toml"),"w")do io;TOML.print(io,Dict("rows"=>out));end
