#= Exact finite-source data for E7/E8 using CHEVIE0.1.15.

Only verified actual source mechanisms are admitted: type A cell ideals,
classical B/D minuscule spherical modules, and E6/E7 minuscule spherical
modules. This tests a general source-coverage criterion; it does not compute
p-canonical bases and an uncovered character is not a counterexample.
=#
using Chevie

const EXCEPTIONAL_OUTPUT = joinpath(@__DIR__, "exceptional_source_tables")
mkpath(EXCEPTIONAL_OUTPUT)

function rational_weyl_table!(H)
    # CHEVIE0.1.15's product-table builder asks for prime power maps beyond
    # the stored E7 maps (e.g.11). Every entry of a Weyl character table is
    # rational: if gcd(m,|H|)=1, Galois invariance gives g^m conjugate to g.
    # Thus the missing coprime maps are exactly the identity, not guesses.
    tables=CharTable[CharTable(t) for t in refltype(H)]
    for (t,ct) in zip(refltype(H),tables)
        if haskey(ct,:powermaps) && haskey(ct,:orders)
            @assert all(x->x==Int(x),ct.irr)
            # ClassInfo maintains a separate optional map cache; complete
            # its shared vector too, so conjugacy-class fusion can use it.
            cin=classinfo(t)
            pmlists=haskey(cin,:powermaps) ? [ct.powermaps,cin.powermaps] : [ct.powermaps]
            for pm in pmlists
                needed=maximum(ct.orders)
                append!(pm,fill(nothing,max(0,needed-length(pm))))
                for m in eachindex(pm)
                    if isnothing(pm[m]) && gcd(m,ct.order)==1
                        pm[m]=collect(eachindex(ct.orders))
                    end
                end
            end
        end
    end
    H.chartable=prod(tables)
    H.chartable
end

function minuscule_seed_indices(H)
    Kinds=Int[]
    for t in refltype(H)
        if t.series == :A
            # All type A cell ideals are p-based; every irreducible is allowed.
        elseif t.series in (:B,:C,:D)
            append!(Kinds,t.indices[2:end])
        elseif t.series == :E && t.rank == 6
            append!(Kinds,t.indices[2:end])
        elseif t.series == :E && t.rank == 7
            append!(Kinds,t.indices[1:6])
        else
            # The longest element alone is always an actual source.
            append!(Kinds,t.indices)
        end
    end
    K=reflection_subgroup(H,Kinds)
    rational_weyl_table!(K); rational_weyl_table!(H)
    tbl=induction_table(K,H).scalar
    return findall(>(0),tbl[:,charinfo(K).positionDet]),string(K)
end

function family_special_map(H)
    ci=charinfo(H); n=length(ci.b); answer=zeros(Int,n)
    for fam in UnipotentCharacters(H).families
        inds=filter(i->i<=n,fam.charNumbers)
        isempty(inds) && continue
        sp=filter(i->ci.a[i]==ci.b[i],inds)
        @assert length(sp)==1 (H,inds,sp)
        answer[inds].=only(sp)
    end
    @assert all(>(0),answer)
    answer
end

function exceptional_sources(n)
    W=coxgroup(:E,n); rational_weyl_table!(W)
    ci=charinfo(W); names=charnames(W)
    U=UnipotentClasses(W); pairs=U.springerseries[1][:locsys]
    ordermat=incidence(U.orderclasses); nw=length(names)
    charfile=joinpath(EXCEPTIONAL_OUTPUT,"E$(n)_characters.tsv")
    open(charfile,"w") do io
        println(io,"index\tcharacter\ta\tb\torbit_index\torbit\tlocal_system\tSpringer_dim")
        for i in 1:nw
            cl,ls=pairs[i]
            println(io,join((i,names[i],ci.a[i],ci.b[i],cl,U.classes[cl].name,ls,U.classes[cl].dimBu),'\t'))
        end
    end
    open(joinpath(EXCEPTIONAL_OUTPUT,"E$(n)_orbit_order.tsv"),"w") do io
        println(io,"lower\tupper")
        for i in eachindex(U.classes),j in eachindex(U.classes)
            ordermat[i,j] && println(io,"$i\t$j")
        end
    end
    simple=vcat(collect(1:n),[highest_short_root(W)])
    seeds=[]; violations=[]
    for omitted in eachindex(simple)
        inds=simple[setdiff(eachindex(simple),[omitted])]
        H=reflection_subgroup(W,inds); hc=charinfo(H)
        selected,Kname=minuscule_seed_indices(H)
        sp=family_special_map(H)
        induction=induction_table(H,W).scalar
        hnames=charnames(H)
        for j in selected
            sj=sp[j]
            ji=findall(i->induction[i,sj]>0 && ci.b[i]==hc.b[sj],1:nw)
            @assert length(ji)==1 (H,j,sj,ji)
            @assert induction[only(ji),sj]==1
            orbit=pairs[only(ji)][1]
            hits=findall(>(0),induction[:,j])
            for i in hits
                ordermat[pairs[i][1],orbit] || push!(violations,(omitted,j,i,orbit))
            end
            push!(seeds,(omitted,string(H),Kname,j,hnames[j],sj,hnames[sj],hc.a[j],hc.b[j],orbit,U.classes[orbit].name,hits))
        end
        println("E$n affine omission $omitted: $H, $(length(selected)) selected source isotypes")
        flush(stdout)
    end
    @assert isempty(violations) violations
    open(joinpath(EXCEPTIONAL_OUTPUT,"E$(n)_sources.tsv"),"w") do io
        println(io,"omitted_node\tH\tK\tH_character_index\tH_character\tfamily_special_index\tfamily_special\ta\tb\torbit_index\torbit\thit_W_characters")
        for s in seeds
            println(io,join((s[1:11]...,join(s[12],',')),'\t'))
        end
    end
    exact=Int[]; missing=Int[]
    for i in 1:nw
        own=pairs[i][1]
        any(s->i in s[12] && ordermat[s[10],own],seeds) ? push!(exact,i) : push!(missing,i)
    end
    open(joinpath(EXCEPTIONAL_OUTPUT,"E$(n)_direct_coverage.tsv"),"w") do io
        println(io,"index\tcharacter\torbit\tb\tcovered_by_direct_source")
        for i in sortperm(ci.b,rev=true)
            println(io,join((i,names[i],U.classes[pairs[i][1]].name,ci.b[i],i in exact),'\t'))
        end
    end
    println("E$n DIRECT $(length(exact))/$nw; missing $(length(missing)); source consistency violations $(length(violations))")
    for i in sort(missing,by=i->-ci.b[i])
        println("  ",names[i]," b=",ci.b[i]," orbit=",U.classes[pairs[i][1]].name)
    end
    flush(stdout)
    (W=W,U=U,ci=ci,seeds=seeds,missing=missing)
end

E7_coverage=exceptional_sources(7)
E8_coverage=exceptional_sources(8)
