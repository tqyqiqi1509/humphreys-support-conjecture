# Include exceptional_positive_source_coverage.jl first.
# Each retained isotypic ideal is justified by a realizable ordinary Levi L:
# f in A[E]^det_L, Delta_L in the Richardson source, and star_L retain f.
# Full-rank pseudo-Levi subgroups are deliberately excluded from this step.

function richardson_retention(data,n;hypothetical_adjoint=false,filetag="")
    W,U,ci=data.W,data.U,data.ci
    pairs=U.springerseries[1][:locsys]; ordermat=incidence(U.orderclasses)
    nw=length(ci.b); names=charnames(W); nc=length(U.classes)
    cuts=[]
    for inds in parabolic_reps(W)
        L=reflection_subgroup(W,inds); rational_weyl_table!(L)
        li=charinfo(L); occ=induction_table(L,W).scalar[:,li.positionDet]
        hit=findall(>(0),occ)
        ji=filter(i->ci.b[i]==li.b[li.positionDet],hit)
        @assert length(ji)==1 (L,ji)
        cl=pairs[only(ji)][1]
        @assert all(i->ordermat[pairs[i][1],cl],hit)
        push!(cuts,(inds,string(L),cl,U.classes[cl].name,hit))
    end
    open(joinpath(EXCEPTIONAL_OUTPUT,"E$(n)$(filetag)_richardson_cuts.tsv"),"w") do io
        println(io,"simple_nodes\tLevi\torbit_index\torbit\tretained_W_characters")
        for c in cuts
            println(io,join((join(c[1],','),c[2],c[3],c[4],join(c[5],',')),'\t'))
        end
    end
    # Unit source is the full coefficient ring and has regular orbit bound.
    regular=pairs[ci.positionId][1]
    source_bounds=[(s[10],s[12],"affine_$(s[1])_char_$(s[4])") for s in data.seeds]
    push!(source_bounds,(regular,collect(1:nw),"unit"))
    adjoint=[]
    if hypothetical_adjoint
        K=reflection_subgroup(W,collect(1:n-1)); rational_weyl_table!(K)
        occ=induction_table(K,W).scalar[:,charinfo(K).positionDet]
        fs=family_special_map(W)
        for i in findall(>(0),occ)
            cl=pairs[fs[i]][1]
            push!(adjoint,(cl,[i],"HYPOTHETICAL_adjoint_$(i)"))
        end
        println("E$n hypothetical adjoint spectrum: ",[(names[only(s[2])],U.classes[s[1]].name) for s in adjoint])
    end
    outcomes=[]
    for i in 1:nw
        allowed=trues(nc)
        selected=filter(c->i in c[5],cuts)
        for c in selected
            allowed .&= ordermat[:,c[3]]
        end
        own=pairs[i][1]
        @assert allowed[own]
        witness=nothing; hypothetical_witness=nothing
        for s in source_bounds
            i in s[2] || continue
            bound=allowed .& ordermat[:,s[1]]
            if all(k->!bound[k] || ordermat[k,own],1:nc)
                witness=s[3];break
            end
        end
        if isnothing(witness)
            for s in adjoint
                i in s[2] || continue
                bound=allowed .& ordermat[:,s[1]]
                if all(k->!bound[k] || ordermat[k,own],1:nc)
                    hypothetical_witness=s[3];break
                end
            end
        end
        # Explicitly identify the trivial local system; CHEVIE's index1
        # need not be trivial (for S2 it is the sign character).
        trivial=pairs[i][2]==charinfo(U.classes[own].Au).positionId
        push!(outcomes,(i,names[i],U.classes[own].name,ci.b[i],trivial,!isnothing(witness),!isnothing(hypothetical_witness),string(witness),string(hypothetical_witness)))
    end
    open(joinpath(EXCEPTIONAL_OUTPUT,"E$(n)$(filetag)_retention_coverage.tsv"),"w") do io
        println(io,"index\tcharacter\torbit\tb\ttrivial_local_system\tcovered\tonly_hypothetical_adjoint\twitness\thypothetical_witness")
        for o in sort(outcomes,by=o->-o[4])
            println(io,join(o,'\t'))
        end
    end
    println("E$n safe retained coverage=",count(o->o[6],outcomes),"/$nw; additional hypothetical adjoint=",count(o->o[7],outcomes))
    for o in sort(filter(o->!o[6],outcomes),by=o->-o[4])
        println("  ",o[2]," orbit=",o[3]," b=",o[4]," trivialLS=",o[5]," adjoint=",o[7])
    end
    flush(stdout)
    outcomes
end

E7_retention=richardson_retention(E7_coverage,7)
E8_retention=richardson_retention(E8_coverage,8;hypothetical_adjoint=true)

# Complete character-table export for independent exact orthogonality checks.
for n in (7,8)
    ct=CharTable(coxgroup(:E,n))
    open(joinpath(EXCEPTIONAL_OUTPUT,"E$(n)_character_matrix.csv"),"w") do io
        for row in eachrow(ct.irr)
            println(io,join(Int.(row),','))
        end
    end
    open(joinpath(EXCEPTIONAL_OUTPUT,"E$(n)_centralizers.csv"),"w") do io
        println(io,join(ct.centralizers,','))
    end
end
