# Final E8 vertex check, restricted initially to the nine maximal proper
# affine parabolics. Each source is actual; no hypothetical character is used.
# Run ONE vertex per process so no large transversal survives into the next.
using Chevie,TOML
basepath=joinpath(@__DIR__,"exceptional_positive_source_coverage.jl")
include_string(Main,first(split(read(basepath,String),"E7_coverage=exceptional_sources(7)")),basepath)
include(joinpath(@__DIR__,"exceptional_semisimple_trace_coverage.jl"))

function final_maximal_data(;allmasks=false)
 W=coxgroup(:E,8);rational_weyl_table!(W)
 U=UnipotentClasses(W);ci=charinfo(W);names=charnames(W)
 masks=allmasks ? Set(0:510) : Set(511-(1<<(j-1)) for j=1:9)
 seeds=[]
 for line in readlines(joinpath(EXCEPTIONAL_OUTPUT,"E8_allaffine_upgraded_sources.tsv"))[2:end]
  r=split(line,'\t');mask=parse(Int,r[1]);mask in masks||continue
  push!(seeds,(mask,String(r[2]),String(r[3]),parse(Int,r[4]),String(r[5]),parse(Int,r[6]),String(r[7]),parse(Int,r[8]),parse(Int,r[9]),parse(Int,r[10]),String(r[11]),parse.(Int,split(r[12],','))))
 end
 @assert Set(s[1] for s in seeds)==masks
 pg=U.springerseries[1][:locsys];sp=family_special_map(W)
 for label in ["phi1050,34","phi560,47","phi210,52","phi50,56"]
  j=findfirst(==(label),names);sj=sp[j];o=pg[sj][1]
  @assert ci.a[j]==ci.b[sj]
  any(s->s[1]==255&&s[4]==j,seeds)||push!(seeds,(255,string(W),"actual_Jensen_2026_session_certificate",j,label,sj,names[sj],ci.a[j],ci.b[j],o,U.classes[o].name,[j]))
 end
 H=reflection_subgroup(W,vcat(collect(2:8),[highest_short_root(W)]));rational_weyl_table!(H)
 hc=charinfo(H);hn=charnames(H);j=28;@assert hn[j]==".22211" && hc.a[j]==24 && hc.b[j]==26
 sj=family_special_map(H)[j];@assert hc.a[sj]==24&&hc.b[sj]==24
 ih=induction_table(H,W).scalar
 jj=findall(k->ih[k,sj]>0&&ci.b[k]==24,eachindex(ci.b));@assert length(jj)==1
 o=pg[only(jj)][1]
 any(s->s[1]==510&&s[4]==j,seeds)||push!(seeds,(510,string(H),"actual_D8_even_nullcone_RSK_family",j,hn[j],sj,hn[sj],hc.a[j],hc.b[j],o,U.classes[o].name,findall(>(0),ih[:,j])))
 sourcetag=allmasks ? "all" : "maximal"
 open(joinpath(EXCEPTIONAL_OUTPUT,"E8_final_$(sourcetag)_actual_sources.tsv"),"w") do io
  println(io,"affine_subset_mask\tH\tprovenance\tH_character_index\tH_character\tfamily_special_index\tfamily_special\ta\tb\torbit_index\torbit\thit_W_characters")
  for s in seeds;println(io,join((s[1:11]...,join(s[12],',')),'\t'));end
 end
 (W=W,U=U,ci=ci,seeds=seeds)
end

function final_maximal_vertex(yindex;adaptive=false)
 data=final_maximal_data(allmasks=adaptive);n=8;Wsc=rootdatum(:E8);ys=quasi_isolated_reps(Wsc)
 ctx=semisimple_trace_setup(Wsc,ys[yindex]);W,M=ctx.W,ctx.M;U=data.U;UM=UnipotentClasses(M)
 pg=U.springerseries[1][:locsys];pm=UM.springerseries[1][:locsys]
 og=incidence(U.orderclasses);cm=charinfo(M);mn=charnames(M);nm=length(cm.b)
 embedded=[findfirst(c->c.dynkin==induced_linear_form(Wsc,M,u.dynkin),U.classes) for u in UM.classes]
 @assert all(!isnothing,embedded)
 trivial=[ls==charinfo(UM.classes[o].Au).positionId for(o,ls)in pm]
 allowed=[trues(length(U.classes)) for _=1:nm];cuts=[]
 println("MAXIMAL_START y",yindex," M=",isomorphism_type(M)," orbit=",length(ctx.reps)," chars=",nm);flush(stdout)
 for inds in parabolic_reps(M)
  L=reflection_subgroup(M,inds);rational_weyl_table!(L);cl=charinfo(L)
  im=induction_table(L,M).scalar[:,cl.positionDet];ig=induction_table(L,W).scalar[:,cl.positionDet]
  jj=findall(i->ig[i]>0&&data.ci.b[i]==cl.b[cl.positionDet],eachindex(ig));@assert length(jj)==1
  o=pg[only(jj)][1];hit=findall(>(0),im)
  @assert all(i->og[embedded[pm[i][1]],o],hit)
  for i in hit;allowed[i].&=og[:,o];end
  push!(cuts,(string(L),o,hit))
 end
 println("MAXIMAL_CUTS y",yindex," count=",length(cuts));flush(stdout)
 witnesses=fill("",nm);sourcerows=[]
 if adaptive
  oldpath=joinpath(EXCEPTIONAL_OUTPUT,"E8_semisimple_$(yindex)_final_maximal_coverage.tsv")
  for line in readlines(oldpath)[2:end]
   r=split(line,'\t');i=parse(Int,r[1]);@assert r[2]==mn[i]
   r[7]=="true"&&(witnesses[i]=String(r[8]))
  end
 end
 tag=adaptive ? "final_adaptive" : "final_maximal"
 function checkpoint(mask)
  file=joinpath(EXCEPTIONAL_OUTPUT,"E8_semisimple_$(yindex)_$(tag)_coverage.tsv")
  open(file,"w")do io
   println(io,"index\tcharacter\tlocal_orbit\tambient_orbit\tb\ttrivial_local_system\tcovered\twitness")
   for i=1:nm
    o,ls=pm[i];println(io,join((i,mn[i],UM.classes[o].name,U.classes[embedded[o]].name,cm.b[i],trivial[i],!isempty(witnesses[i]),witnesses[i]),'\t'))
   end
  end
  println("MAXIMAL_PROGRESS y",yindex," mask=",mask," all=",count(!isempty,witnesses),"/",nm," trivial=",count(i->trivial[i]&&!isempty(witnesses[i]),1:nm),"/",count(trivial));flush(stdout)
 end
 simple=vcat(collect(1:n),[highest_short_root(W)])
 masks=sort(unique(s[1] for s in data.seeds),by=m->(-count_ones(m),m))
 function useful(s)
  any(1:nm)do i
   trivial[i]&&isempty(witnesses[i])||return false
   target=embedded[pm[i][1]];inter=allowed[i].&og[:,s[10]]
   all(k->!inter[k]||og[k,target],eachindex(inter))
  end
 end
 if adaptive
  maxmasks=Set(511-(1<<(j-1)) for j=1:9)
  masks=filter(m->!(m in maxmasks)&&any(useful,filter(s->s[1]==m,data.seeds)),masks)
  println("ADAPTIVE_ELIGIBLE y",yindex," masks=",masks);flush(stdout)
 end
 for mask in masks
  selected=filter(s->s[1]==mask&&(!adaptive||useful(s)),data.seeds)
  isempty(selected)&&continue
  H=reflection_subgroup(W,[simple[j] for j=1:9 if !iszero(mask&(1<<(j-1)))])
  mult=affine_restriction_multiplicities(ctx,H,affine_fixed_weight(Wsc,mask,n))
  for s in selected
   bound=s[10];hit=findall(>(0),mult[s[4],:])
   @assert all(i->og[embedded[pm[i][1]],bound],hit) (yindex,mask,s[4],bound,hit)
   for i in hit
    target=embedded[pm[i][1]];inter=allowed[i].&og[:,bound]
    valid=all(k->!inter[k]||og[k,target],eachindex(inter))
    push!(sourcerows,(mask,s[4],s[5],U.classes[bound].name,i,mn[i],U.classes[target].name,mult[s[4],i],valid))
    valid&&isempty(witnesses[i])&&(witnesses[i]="mask$(mask)_char$(s[4])")
   end
  end
  checkpoint(mask)
  empty!(ctx.fixed);empty!(ctx.matrices);GC.gc()
  all(i->!trivial[i]||!isempty(witnesses[i]),1:nm)&&break
 end
 open(joinpath(EXCEPTIONAL_OUTPUT,"E8_semisimple_$(yindex)_$(tag)_witnesses.tsv"),"w")do io
  println(io,"affine_mask\tH_index\tH_character\tsource_bound\tlocal_index\tlocal_character\tambient_target\tmultiplicity\tcut_succeeds")
  for r in sourcerows;println(io,join(r,'\t'));end
 end
 for i=1:nm
  trivial[i]&&isempty(witnesses[i])&&println("MISSING y",yindex," ",(i,mn[i],UM.classes[pm[i][1]].name,U.classes[embedded[pm[i][1]]].name,cm.b[i]))
 end
 println("MAXIMAL_DONE y",yindex);flush(stdout)
end
@assert length(ARGS)in(1,2)
final_maximal_vertex(parse(Int,ARGS[1]);adaptive=length(ARGS)==2&&ARGS[2]=="adaptive")
