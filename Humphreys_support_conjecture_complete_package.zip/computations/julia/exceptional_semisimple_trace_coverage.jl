# Exact affine finite-subgroup characters on a semisimple coefficient germ.
# No assumption that H intersect W_y is a reflection subgroup is made.
# Run after exceptional_positive_source_coverage.jl and all-affine sources.

function affine_fixed_weight(Wsc,mask,n)
    xi=zeros(Rational{Int},n)
    if !iszero(mask & (1<<n))
        k=findfirst(j->iszero(mask & (1<<(j-1))),1:n)
        @assert !isnothing(k)
        simplecor=hcat(coroots(Wsc)[1:n]...).//1
        marks=simplecor\(coroots(Wsc)[highest_short_root(Wsc)].//1)
        values=zeros(Rational{Int},n);values[k]=1/marks[k]
        xi=transpose(simplecor)\values
    end
    xi
end

# Constructive next-source finder: these are CANDIDATE finite blocks, not
# assertions of p-independence. It names exactly which new positive input
# would fill each remaining local generator.
function missing_finite_block_candidates(data,n,vertex,yindex)
    ctx=vertex.ctx; W=ctx.W; U=data.U; pg=U.springerseries[1][:locsys]
    UM=UnipotentClasses(ctx.M); pm=UM.springerseries[1][:locsys]
    og=incidence(U.orderclasses); rows=[]
    misses=filter(r->r[6]&&!r[7],vertex.outcomes)
    simple=vcat(collect(1:n),[highest_short_root(W)])
    for mask in sort(unique(s[1] for s in data.seeds))
        inds=[simple[j] for j in 1:n+1 if !iszero(mask & (1<<(j-1)))]
        H=reflection_subgroup(W,inds); hc=charinfo(H)
        mult=affine_restriction_multiplicities(ctx,H,affine_fixed_weight(ctx.Wsc,mask,n))
        sp=family_special_map(H); ind=induction_table(H,W).scalar
        names=charnames(H); selected=Set(s[4] for s in data.seeds if s[1]==mask)
        for miss in misses
            i=miss[1]; target=vertex.embedded[pm[i][1]]
            allowed=trues(length(U.classes))
            for c in vertex.cuts
                i in c[3] && (allowed .&=og[:,c[2]])
            end
            for j in findall(>(0),mult[:,i])
                j in selected && continue
                sj=sp[j]
                jj=findall(k->ind[k,sj]>0 && data.ci.b[k]==hc.b[sj],eachindex(data.ci.b))
                @assert length(jj)==1
                bound=pg[only(jj)][1]
                inter=allowed .& og[:,bound]
                all(k->!inter[k] || og[k,target],eachindex(inter)) || continue
                push!(rows,(i,miss[2],miss[4],mask,isomorphism_type(H),order(H),j,names[j],hc.a[j],hc.b[j],U.classes[bound].name,mult[j,i]))
            end
        end
    end
    sort!(rows,by=r->(r[1],r[6],r[9],r[10],r[4],r[7]))
    open(joinpath(EXCEPTIONAL_OUTPUT,"E$(n)_semisimple_$(yindex)_new_block_candidates.tsv"),"w") do io
        println(io,"local_index\tlocal_character\tambient_target\taffine_mask\tH_type\tH_order\tH_index\tH_character\ta\tb\tseed_orbit\tmultiplicity")
        for r in rows;println(io,join(r,'\t'));end
    end
    println("E$n y$yindex new-block candidates $(length(rows))")
    for miss in misses
        hits=filter(r->r[1]==miss[1],rows)
        println("  ",miss[2]," => ",hits[1:min(4,length(hits))])
    end
    flush(stdout);rows
end

function semisimple_trace_setup(Wsc,y)
    W=coxgroup(:E,rank(Wsc)); M=centralizer(Wsc,y).group
    rational_weyl_table!(M)
    trans=transversal(Wsc,y); points=collect(keys(trans)); reps=collect(values(trans))
    ell=order(y); qmat=hcat([Int.(ell.*[z.r for z in a.v]) for a in points]...)
    @assert size(qmat,2)==order(W)÷order(M)
    (Wsc=Wsc,W=W,M=M,y=y,ell=ell,qmat=qmat,reps=reps,
     ctm=CharTable(M),fixed=Dict{Any,Any}(),matrices=Dict{Any,Any}())
end

function fixed_class_data!(ctx,h)
    get!(ctx.fixed,h) do
        mat=get!(ctx.matrices,h) do; Int.(reflrep(ctx.Wsc,h)); end
        qs=ctx.qmat; ell=ctx.ell; M=ctx.M
        ans=Tuple{Int,Int}[]
        if isone(h)
            cl=position_class(M,h)
            append!(ans,[(j,cl) for j in axes(qs,2)])
            return ans
        end
        for j in axes(qs,2)
            fixed=true
            for a in axes(qs,1)
                s=-qs[a,j]
                for b in axes(qs,1); s+=mat[a,b]*qs[b,j]; end
                if !iszero(mod(s,ell)); fixed=false;break;end
            end
            fixed || continue
            t=ctx.reps[j]; g=t*h*inv(t)
            push!(ans,(j,position_class(M,g)))
        end
        ans
    end
end

function affine_restriction_multiplicities(ctx,H,xi)
    rational_weyl_table!(H)
    # An integral xi is removed by a global Laurent-monomial conjugation.
    # Mackey then equals Res_H Ind_M^W, computed by two ordinary tables.
    if all(x->denominator(x)==1,xi)
        a=induction_table(H,ctx.W).scalar
        b=induction_table(ctx.M,ctx.W).scalar
        mult=transpose(a)*b
        @assert all(mult.>=0)
        dimsH=CharTable(H).irr[:,position_class(H,one(H))]
        dimsM=ctx.ctm.irr[:,position_class(ctx.M,one(ctx.M))]
        @assert vec(transpose(dimsH)*mult)==length(ctx.reps).*dimsM
        return mult
    end
    cth=CharTable(H)
    hs=classreps(H); nm=size(ctx.ctm.irr,1)
    CT=typeof(E(ctx.ell)+0)
    traces=zeros(CT,nm,length(hs))
    for (a,h) in enumerate(hs)
        mat=get!(ctx.matrices,h) do; Int.(reflrep(ctx.Wsc,h)); end
        if isone(h)
            traces[:,a].=length(ctx.reps).*ctx.ctm.irr[:,position_class(ctx.M,one(ctx.M))]
            continue
        end
        lam=xi-vec(transpose(xi)*mat)
        @assert all(x->denominator(x)==1,lam)
        lam=Int.(lam)
        for (j,cl) in fixed_class_data!(ctx,h)
            phase=E(ctx.ell,mod(sum(lam.*ctx.qmat[:,j]),ctx.ell))
            traces[:,a].+=phase.*ctx.ctm.irr[:,cl]
        end
    end
    raw=(cth.irr .// transpose(cth.centralizers))*transpose(traces)
    mult=Int.(raw)
    @assert all(raw.==mult) && all(mult.>=0)
    # Independent degree identity for every M-character.
    dimsH=cth.irr[:,position_class(H,one(H))]
    dimsM=ctx.ctm.irr[:,position_class(ctx.M,one(ctx.M))]
    @assert vec(transpose(dimsH)*mult)==length(ctx.reps).*dimsM
    if length(ctx.reps)==1 && isone(ctx.y)
        @assert mult==transpose(induction_table(H,ctx.W).scalar)
    end
    mult
end

function exceptional_semisimple_coverage(data,n,yindex;maxmasks=typemax(Int),filetag="")
    Wsc=rootdatum(n==8 ? :E8 : Symbol("E$(n)sc")); ys=quasi_isolated_reps(Wsc)
    y=ys[yindex]; ctx=semisimple_trace_setup(Wsc,y)
    W,M=ctx.W,ctx.M; U=data.U; UM=UnipotentClasses(M)
    pg=U.springerseries[1][:locsys]; pm=UM.springerseries[1][:locsys]
    og=incidence(U.orderclasses); ciM=charinfo(M); nm=length(ciM.b)
    # M inherits the simply-connected character basis; use that SAME root
    # realization for the Dynkin-diagram embedding, not the adjoint one.
    embedded=[findfirst(c->c.dynkin==induced_linear_form(Wsc,M,u.dynkin),U.classes) for u in UM.classes]
    @assert all(!isnothing,embedded)
    cuts=[]
    for inds in parabolic_reps(M)
        L=reflection_subgroup(M,inds); rational_weyl_table!(L)
        cl=charinfo(L); im=induction_table(L,M).scalar[:,cl.positionDet]
        ig=induction_table(L,W).scalar[:,cl.positionDet]
        jj=findall(i->ig[i]>0 && data.ci.b[i]==cl.b[cl.positionDet],eachindex(ig))
        @assert length(jj)==1
        orbit=pg[only(jj)][1]; hit=findall(>(0),im)
        @assert all(i->og[embedded[pm[i][1]],orbit],hit)
        push!(cuts,(string(L),orbit,hit))
    end
    allowed=[trues(length(U.classes)) for _ in 1:nm]
    for i in 1:nm,c in cuts
        i in c[3] && (allowed[i].&=og[:,c[2]])
    end
    witnesses=fill("",nm); sources=[]; countm=0
    masks=sort(unique(s[1] for s in data.seeds))
    println("E$n y$yindex order$(ctx.ell) M=$(isomorphism_type(M)), orbit=$(length(ctx.reps)), chars=$nm, cuts=$(length(cuts))");flush(stdout)
    simple=vcat(collect(1:n),[highest_short_root(W)])
    for mask in masks
        countm+=1; countm>maxmasks && break
        inds=[simple[j] for j in 1:n+1 if !iszero(mask & (1<<(j-1)))]
        H=reflection_subgroup(W,inds); xi=affine_fixed_weight(Wsc,mask,n)
        mult=affine_restriction_multiplicities(ctx,H,xi)
        for s in filter(s->s[1]==mask,data.seeds)
            hit=findall(>(0),mult[s[4],:]); bound=s[10]
            @assert all(i->og[embedded[pm[i][1]],bound],hit) (yindex,mask,s[4],hit,bound)
            push!(sources,(mask,s[4],bound,hit))
            for i in hit
                isempty(witnesses[i]) || continue
                target=embedded[pm[i][1]]
                intersection=allowed[i].&og[:,bound]
                if all(k->!intersection[k] || og[k,target],eachindex(intersection))
                    witnesses[i]="mask$(mask)_char$(s[4])"
                end
            end
        end
        if countm%25==0
            println("E$n y$yindex masks$countm covered$(count(!isempty,witnesses))/$nm");flush(stdout)
        end
    end
    file=joinpath(EXCEPTIONAL_OUTPUT,"E$(n)_semisimple_$(yindex)$(filetag)_coverage.tsv")
    outcomes=[]
    open(file,"w") do io
        println(io,"index\tcharacter\tlocal_orbit\tambient_orbit\tb\ttrivial_local_system\tcovered\twitness")
        for i in 1:nm
            o,ls=pm[i]; tr=ls==charinfo(UM.classes[o].Au).positionId
            row=(i,charnames(M)[i],UM.classes[o].name,U.classes[embedded[o]].name,ciM.b[i],tr,!isempty(witnesses[i]),witnesses[i])
            push!(outcomes,row);println(io,join(row,'\t'))
        end
    end
    println("E$n y$yindex FINISHED masks=$(min(countm,length(masks))) whole=$(count(r->r[7],outcomes))/$nm trivial=$(count(r->r[6]&&r[7],outcomes))/$(count(r->r[6],outcomes))")
    for r in outcomes
        r[6] && !r[7] && println("  missing trivial ",r)
    end
    flush(stdout)
    (ctx=ctx,outcomes=outcomes,sources=sources,cuts=cuts,embedded=embedded)
end
