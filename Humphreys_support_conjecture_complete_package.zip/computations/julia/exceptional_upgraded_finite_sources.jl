# Source upgrade: published complete rank<=6 simply-laced p-canonical
# tables (Elias--Jensen/Gibson 2111.12190v2 §5.4), and the two actual
# E7 canonical elements proved in EXCEPTIONAL_PARTIAL_LEVI_SOURCE_INFLATION.md.
# Source259 phi15 is independently checked by exact representation matrices.
# All uses here are in p>h(E7/E8), hence p>7.
function certified_finite_seed_indices(H)
    Kinds=Int[]
    for t in refltype(H)
        if t.series==:A
            # Every type-A cell has an actual parabolic-longest source;
            # this does NOT assert equality of the whole type-A p-basis.
        elseif t.series in (:D,:E) && t.rank<=6
            # Published full ordinary/p-canonical equality for p>7.
        elseif t.series in (:B,:C,:D)
            append!(Kinds,t.indices[2:end])
        elseif t.series==:E && t.rank==7
            append!(Kinds,t.indices[1:6])
        else
            append!(Kinds,t.indices)
        end
    end
    K=reflection_subgroup(H,Kinds)
    rational_weyl_table!(K);rational_weyl_table!(H)
    selected=Set(findall(>(0),induction_table(K,H).scalar[:,charinfo(K).positionDet]))
    for t in refltype(H)
        t.series==:E && t.rank in (7,8) || continue
        F=reflection_subgroup(H,t.indices);rational_weyl_table!(F)
        wanted=t.rank==7 ? ("phi15,28","phi189,22") : ("phi8,91","phi35,74","phi1400,32")
        idx=findall(x->x in wanted,charnames(F))
        @assert length(idx)==length(wanted) (F,charnames(F))
        tab=induction_table(F,H).scalar
        for j in idx;union!(selected,findall(>(0),tab[:,j]));end
    end
    sort!(collect(selected)),"rank6_pgt7_E7actual259_43_E8actual1540_191_232_minuscule"
end

# Extend verified sources to ALL proper finite affine standard parabolics.
# Root projections that coincide are deduplicated only at the central germ1,
# where all affine translation cocycles are trivial. No claim at other germs.

function all_affine_sources_upgraded(data,n)
    W,U,ci=data.W,data.U,data.ci; nw=length(ci.b)
    pairs=U.springerseries[1][:locsys]; om=incidence(U.orderclasses)
    simple=vcat(collect(1:n),[highest_short_root(W)])
    seen=Set{Tuple}(); seeds=[]; checked=0
    for mask in 0:(2^(n+1)-2)
        inds=[simple[j] for j in 1:n+1 if !iszero(mask & (1<<(j-1)))]
        H=reflection_subgroup(W,inds)
        key=Tuple(sort(inclusion(H,1:nref(H))))
        key in seen && continue
        push!(seen,key)
        selected,Kname=certified_finite_seed_indices(H)
        hc=charinfo(H); sp=family_special_map(H)
        ind=induction_table(H,W).scalar; hn=charnames(H)
        for j in selected
            sj=sp[j]
            ji=findall(i->ind[i,sj]>0 && ci.b[i]==hc.b[sj],1:nw)
            @assert length(ji)==1 (H,j,sj,ji)
            @assert ind[only(ji),sj]==1
            orbit=pairs[only(ji)][1]; hits=findall(>(0),ind[:,j])
            @assert all(i->om[pairs[i][1],orbit],hits) (H,j,orbit,hits)
            push!(seeds,(mask,string(H),Kname,j,hn[j],sj,hn[sj],hc.a[j],hc.b[j],orbit,U.classes[orbit].name,hits))
        end
        checked+=1
        if checked%40==0
            println("E$n all-affine processed $checked projected subgroups, $(length(seeds)) source blocks");flush(stdout)
        end
    end
    open(joinpath(EXCEPTIONAL_OUTPUT,"E$(n)_allaffine_upgraded_sources.tsv"),"w") do io
        println(io,"affine_subset_mask\tH\tK\tH_character_index\tH_character\tfamily_special_index\tfamily_special\ta\tb\torbit_index\torbit\thit_W_characters")
        for s in seeds
            println(io,join((s[1:11]...,join(s[12],',')),'\t'))
        end
    end
    println("E$n ALL-AFFINE completed $checked projected finite subgroups, $(length(seeds)) verified source blocks")
    (W=W,U=U,ci=ci,seeds=seeds,missing=Int[])
end
