using Chevie, Serialization, TOML
const vv=Pol()
const VP=typeof(vv)
function add!(a,i,q)
 z=get(a,i,zero(vv))+q
 if iszero(z);delete!(a,i);else;a[i]=z;end
end
function main()
 base=joinpath(@__DIR__,"exceptional_source_tables")
 d=deserialize(joinpath(base,"E8_A7_short_sources.jls"))
 W=coxgroup(:E,8);wJ=longest(reflection_subgroup(W,d.J))
 knownE7=Dict{typeof(one(W)),String}();allE7=Dict{typeof(one(W)),String}()
 for tg in ["A6","D5"]
  for line in readlines(joinpath(base,"E7_$(tg)_short_sources.tsv"))[2:end]
   r=split(line,'\t');g=prod(W.(parse.(Int,split(r[7],','))))
   ref="E7_$(tg)_source$(r[1])_cert$(r[4])"
   allE7[g]=ref;allE7[inv(g)]=ref*"_inverse"
   if r[4]=="true";knownE7[g]=ref;knownE7[inv(g)]=ref*"_inverse";end
  end
 end
 function product(s,z)
  a=Dict{Int,VP}()
  for(i,c)in d.canonical[z]
   j=d.acts[s,i];@assert j>0
   if j==i;add!(a,i,(vv+vv^-1)*c)
   else;add!(a,j,c);add!(a,i,(d.lens[j]>d.lens[i] ? vv : vv^-1)*c);end
  end
  a
 end
 function lower(s,z,i)
  haskey(d.corrections,(s,z))&&return d.corrections[(s,z)]
  a=product(s,z)
  for(k,q)in d.canonical[i];add!(a,k,-q);end
  c=Pair{Int,Int}[]
  for y=i-1:-1:1
   q=get(a,y,zero(vv));iszero(q)&&continue
   @assert degree(q)==0&&valuation(q)==0&&q[0]>0
   push!(c,y=>q[0]);for(k,r)in d.canonical[y];add!(a,k,-q*r);end
  end
  @assert isempty(a)
  c
 end
 function right_factor(g,I)
  u=g;b=one(W)
  while true
   ss=findfirst(s->isrightdescent(W,u,s),I);isnothing(ss)&&return b
   t=I[ss];u=u*W(t);b=W(t)*b
  end
 end
 function details(i,y)
  wi=d.xs[i]*wJ;wy=d.xs[y]*wJ
  out=[]
  for(side,g)in[("left",wi*inv(wy)),("right",inv(wy)*wi)]
   I=sort(unique(word(W,g)));b=right_factor(side=="left" ? inv(wi) : wi,I)
   ref=get(knownE7,b,"");allref=get(allE7,b,"")
   minuscule=""
   if I==collect(1:7)&&all(s->isrightdescent(W,b,s),1:6);minuscule="E7_E6";end
   if I==collect(2:8)
    for o in [2,3,8]
     all(s->isrightdescent(W,b,s),setdiff(I,[o]))&&(minuscule="D7_omit$(o)")
    end
   end
   if I==[1,3,4,5,6,7,8]
    for o in I
     all(s->isrightdescent(W,b,s),setdiff(I,[o]))&&(minuscule="A7_omit$(o)")
    end
   end
   push!(out,Dict("side"=>side,"I"=>I,"relative_word"=>word(W,g),
      "upper_word"=>word(W,b),"upper_length"=>length(W,b),
      "right_descents"=>[s for s in I if isrightdescent(W,b,s)],
      "known_E7"=>ref,"any_E7"=>allref,"minuscule"=>minuscule))
  end
  out
 end
 targets=isempty(ARGS) ? [2794] : parse.(Int,ARGS)
 result=[]
 for i in targets
  ds=[]
  println("TARGET ",i," len ",d.lens[i]," known ",d.known[i]," witness ",d.witness[i])
  for s=1:8
   z=d.acts[s,i];0<z<i||continue
   cc=lower(s,z,i);cr=[]
   println(" DESCENT ",s," z ",z," known ",d.known[z]," corrections ",cc)
   for(y,m)in cc
    det=details(i,y);push!(cr,Dict("lower"=>y,"multiplicity"=>m,"cosets"=>det))
    println("  LOWER ",y," ",det)
   end
   push!(ds,Dict("simple"=>s,"predecessor"=>z,"known"=>d.known[z],"corrections"=>cr))
  end
  push!(result,Dict("target"=>i,"descents"=>ds,"coset_word"=>word(W,d.xs[i]),"full_word"=>word(W,d.xs[i]*wJ)))
 end
 open(joinpath(base,"E8_A7_sources$(join(targets,"_"))_obstructions.toml"),"w")do io;TOML.print(io,Dict("targets"=>result));end
end
main()
