# Independent minimal proof DAG: rank<=6 partial-Levi seeds + Jensen only.
# This intentionally does not use any ERT flags in the input .jls file.
using Chevie, Serialization, TOML
const vv=Pol()
const VP=typeof(vv)
tomlify(x::NamedTuple)=Dict(string(k)=>tomlify(v) for (k,v) in pairs(x))
tomlify(x::AbstractVector)=tomlify.(x)
tomlify(x)=x
function add!(a,i,q)
 z=get(a,i,zero(vv))+q
 if iszero(z);delete!(a,i);else;a[i]=z;end
end
function main()
 d=deserialize("humphreys/compute/exceptional_source_tables/E7_A6_short_sources.jls")
 W=coxgroup(:E,7);H=reflection_subgroup(W,d.J);wJ=longest(H)
 known=falses(length(d.xs));proof=Dict{Int,Any}()
 function product(s,z)
  a=Dict{Int,VP}()
  for(i,c)in d.canonical[z]
   j=d.acts[s,i];@assert j>0
   if j==i;add!(a,i,(vv+vv^-1)*c)
   else;add!(a,j,c);add!(a,i,(d.lens[j]>d.lens[i] ? vv : vv^-1)*c)
   end
  end
  a
 end
 function lower(s,z,i)
  a=product(s,z)
  for(k,q)in d.canonical[i];add!(a,k,-q);end
  c=Pair{Int,Int}[]
  for y=i-1:-1:1
   q=get(a,y,zero(vv));iszero(q)&&continue
   @assert degree(q)==0 && valuation(q)==0 && q[0]>0
   push!(c,y=>q[0])
   for(k,r)in d.canonical[y];add!(a,k,-q*r);end
  end
  @assert isempty(a)
  c
 end
 function cosetproof(i,y,m)
  for(side,g)in [("left",d.xs[i]*inv(d.xs[y])),("right",wJ*inv(d.xs[y])*d.xs[i]*wJ)]
   rw=word(W,g);I=sort(unique(rw))
   length(I)<=6 && return (lower=y,multiplicity=m,coset_side=side,parabolic_nodes=I,relative_word=rw,
      lower_full_word=word(W,d.xs[y]*wJ))
  end
  nothing
 end
 for i=1:length(d.xs)
  I=sort(unique(word(W,d.xs[i])))
  if length(I)<=6
   known[i]=true;proof[i]=(index=i,method="partial_Levi_rank_le6",parabolic_nodes=I,
     intersection_J=intersect(I,d.J),coset_word=word(W,d.xs[i]),full_word=word(W,d.xs[i]*wJ))
   continue
  end
  for s=1:7
   z=d.acts[s,i];(0<z<i && known[z])||continue
   cc=lower(s,z,i);pr=[cosetproof(i,y,m) for(y,m)in cc]
   all(!isnothing,pr)||continue
   @assert W(s)*d.xs[z]==d.xs[i]
   known[i]=true;proof[i]=(index=i,method="Jensen_coset",simple=s,predecessor=z,
      coset_word=word(W,d.xs[i]),full_word=word(W,d.xs[i]*wJ),corrections=pr)
   break
  end
 end
 @assert known[259]
 dag=Int[];i=259
 while true
  push!(dag,i);pr=proof[i];pr.method=="partial_Levi_rank_le6"&&break;i=pr.predecessor
 end
 reverse!(dag)
 used=Set(dag)
 for i in dag
  pr=proof[i]
  if pr.method=="Jensen_coset";for c in pr.corrections;push!(used,c.lower);end;end
 end
 vectors=[]
 for i in sort(collect(used))
  push!(vectors,(index=i,terms=[(index=y,coset_word=word(W,d.xs[y]),
   polynomial=[[e,q[e]] for e in valuation(q):degree(q) if q[e]!=0]) for(y,q)in sort(collect(d.canonical[i]))]))
 end
 receipt=(rank=7,parabolic_J=d.J,p_range="prime p > 7",target=259,
   rule="partial-Levi seed and Jensen Corollary 3.10 only; no ERT input",
   dag=dag,nodes=[proof[i] for i in dag],canonical_vectors=vectors)
 out="humphreys/compute/exceptional_source_tables/E7_phi15_source259_dag.toml"
 open(out,"w")do io;TOML.print(io,tomlify(receipt));end
 println("CERTIFIED",count(known)," DAG",dag)
 for i in dag;println(proof[i]);end
end
main()
