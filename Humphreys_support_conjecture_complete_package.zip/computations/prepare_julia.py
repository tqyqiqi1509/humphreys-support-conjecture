#!/usr/bin/env python3
"""Prepare the original Julia sources in their historical relative layout."""
import argparse
from pathlib import Path
import shutil
import shlex

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("output", type=Path, help="new working directory (must not exist)")
args = parser.parse_args()
out = args.output.resolve()
out.mkdir(parents=True, exist_ok=False)
compute = out / "humphreys" / "compute"
compute.mkdir(parents=True)
for src in (root / "julia").glob("*.jl"):
    shutil.copy2(src, compute / src.name)
shutil.copytree(root / "data" / "exceptional_source_tables", compute / "exceptional_source_tables")
environment = out / "julia_environment"
environment.mkdir()
for filename in ("Project.toml", "Manifest.toml"):
    shutil.copy2(root / "julia" / filename, environment / filename)
print("Prepared:", out)
print("The following commands require Julia and package access; they were not run by this launcher.")
print("cd " + shlex.quote(str(out)))
print("julia --project=julia_environment -e 'using Pkg; Pkg.instantiate()'")
print("julia --project=julia_environment humphreys/compute/run_e7_upgraded_coverage.jl")
print("julia --project=julia_environment humphreys/compute/run_e8_upgraded_coverage.jl")
print("These two scripts reproduce the upgraded coverage stages. See README.txt for the later E8 stages.")
